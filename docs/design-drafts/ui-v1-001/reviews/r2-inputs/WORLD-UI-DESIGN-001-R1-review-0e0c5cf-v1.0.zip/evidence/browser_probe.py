
import asyncio,json,pathlib,sys
from playwright.async_api import async_playwright
async def main():
    port=sys.argv[1];out=pathlib.Path(sys.argv[2])
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        page=await browser.new_page(viewport={'width':1920,'height':1080})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        await page.goto(f'http://127.0.0.1:{port}/prototype/index.html?screen=P01-unselected',wait_until='networkidle')
        await page.screenshot(path=str(out/'mainline-initial-1920.png'))
        d=await page.locator('button').evaluate_all("(es)=>es.map(e=>({text:e.innerText,act:e.dataset.act,disabled:e.disabled}))")
        (out/'browser-initial.json').write_text(json.dumps({'buttons':d,'errors':errors,'viewport':await page.evaluate('({w:innerWidth,h:innerHeight,dpr:devicePixelRatio})')},ensure_ascii=False,indent=2))
        print(json.dumps(d,ensure_ascii=False))
        await browser.close()
asyncio.run(main())
