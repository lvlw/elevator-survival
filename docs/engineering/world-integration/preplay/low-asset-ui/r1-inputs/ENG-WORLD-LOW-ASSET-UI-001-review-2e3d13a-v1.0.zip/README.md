# Mainline combined review evidence

Exact SHA: 2e3d13a52ada1fdcd9848574e918b97db43cb0c2. This ZIP contains the consolidated report, actual source-isolation programs/results and asset/source fingerprint checks. It is NOT a repository clone, an author browser profile, a save export or a Codex execution task.

The separate user-provided original UI asset ZIP is retained unchanged with SHA256 559a1ed3b8f40567934e0ce875dfe6d559b19ac39ef5487e01cf9a857ef76934. Twelve original screenshots were directly inspected. They are not re-rendered or modified here. The self-contained HTML visual report includes those unmodified pixels separately.

Run source checks with a local TypeScript module available. `check-visual-seams.cjs` accepts TYPESCRIPT_MODULE and uses explicit inert React hooks/JSX/child adapters. Its expected current result is 5 matching controls and 2 semantic failures, exit1. It is NOT native DOM/P/R/S/browser proof. `prior-stage/evidence/check-ui-boundaries.cjs` is preserved byte-for-byte from the earlier evidence, including its original environment path; it was rerun here with 25/27 matching and two existing UI-01 semantic failures. Do not add repeated cases to production test counts.
