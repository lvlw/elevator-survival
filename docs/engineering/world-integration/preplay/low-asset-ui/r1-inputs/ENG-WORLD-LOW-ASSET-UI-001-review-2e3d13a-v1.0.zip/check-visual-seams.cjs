// Mainline SOURCE ISOLATION, not native React DOM/P/R/S or a browser.
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const assert = require('node:assert/strict'), crypto = require('node:crypto');
const ts = require(process.env.TYPESCRIPT_MODULE || '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
const root=__dirname;
for(const row of JSON.parse(fs.readFileSync(path.join(root,'source-integrity.json'),'utf8')).filter(r=>!r.source)) {
  const b=fs.readFileSync(path.join(root,'source',row.file));
  assert.equal(crypto.createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${b.length}\0`),b])).digest('hex'),row.git_blob);
}
const jsx=(type,props,key)=>({type,props:props||{},key});
function load(file,deps){
 const source=fs.readFileSync(path.join(root,'source',file),'utf8');
 const output=ts.transpileModule(source,{fileName:file,compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022,jsx:ts.JsxEmit.ReactJSX}}).outputText;
 const m={exports:{}};
 vm.runInThisContext(`(function(require,module,exports){${output}\n})`,{filename:file})(name=>{assert.ok(Object.hasOwn(deps,name),'undeclared TEST adapter '+name);return deps[name]},m,m.exports);
 return m.exports;
}
function nodes(t){if(!t||typeof t!=='object')return [];if(Array.isArray(t))return t.flatMap(nodes);return[t,...nodes(t.props?.children)]}
function text(t){if(t==null||typeof t==='boolean')return '';if(Array.isArray(t))return t.map(text).join('');if(typeof t!=='object')return String(t);return text(t.props?.children)}
const results=[];
function check(id,expectation,fn){try{fn();results.push({id,expectation,result:'PASS'})}catch(e){results.push({id,expectation,result:'FAIL',error:e.name,message:e.message,unexpected:!(e instanceof assert.AssertionError)})}}
const ContextMenu=()=>{},ItemTile=()=>{};
const opaque=()=>Object.freeze({selection:'opaque'});
const action=(family,label)=>({family,label,selector:opaque()});
const medical=action('medical','使用药食'),move=action('inventory','移动物品'),drop=action('inventory','留置'),taskDrop=action('task-transfer','留置任务物');
function item(name,ordinary){return{selector:opaque(),name,ordinary,quantity:1,container:'backpack',slot:null,width:1,height:1,unitWeight:1,footprint:[{x:0,y:0}],placement:{x:0,y:0,rotated:false},stackable:ordinary,quickEligible:ordinary,resource:{kind:'none'}}}
function harness(i,point='stable-active'){
 let cursor=0;const state=['backpack',null],events=[];
 const react={useState:()=>{const k=cursor++;return[state[k],v=>state[k]=v]},useEffect:()=>{}};
 const {InventoryPanel}=load('inventory-panel.tsx',{react,'react/jsx-runtime':{jsx,jsxs:jsx},'./context-menu':{ContextMenu},'./item-tile':{ItemTile},'../labels':{loadName:x=>x}});
 const view={point,actions:point==='battle-decision'?[]:[medical,move,drop,taskDrop],carried:[i],backpack:{width:6,height:4,load:'normal',weight:1},body:{wounds:[]}};
 const render=()=>{cursor=0;return InventoryPanel({view,onAction:(...args)=>events.push(args)})};
 const open=()=>{const tile=nodes(render()).find(n=>n.type===ItemTile);if(tile.props.onMenu)tile.props.onMenu(i,10,10,{focus(){}});return nodes(render()).find(n=>n.type===ContextMenu)};
 return{render,open,state,events,view};
}
check('M01','task module object menu must not offer a medical operation on that object',()=>{
 const h=harness(item('module',false)),m=h.open();assert.ok(m);assert.ok(!m.props.actions.includes(medical),'module menu contains 使用药食');
});
check('M02','ordinary non-medical metal object menu must not offer a medical operation on that object',()=>{
 const h=harness(item('金属零件',true)),m=h.open();assert.ok(m);assert.ok(!m.props.actions.includes(medical),'metal menu contains 使用药食');
});
check('M03','task module retains task-drop and movement, not ordinary drop',()=>{
 const m=harness(item('module',false)).open();assert.ok(m.props.actions.includes(taskDrop));assert.ok(m.props.actions.includes(move));assert.ok(!m.props.actions.includes(drop));
});
check('M04','valid public bandage context retains medical menu entry',()=>{
 const m=harness(item('绷带',true)).open();assert.ok(m.props.actions.includes(medical));
});
check('M05','battle with no stable actions has no inventory interaction menu',()=>{
 const h=harness(item('module',false),'battle-decision');assert.equal(h.open(),undefined);assert.equal(h.events.length,0);
});
check('M06','open and cancel menu do not execute an action',()=>{
 const h=harness(item('module',false)),m=h.open();m.props.onClose();assert.equal(h.events.length,0);assert.equal(h.state[1],null);
});
check('M07','explicit menu movement preserves exact selected action and item references',()=>{
 const i=item('module',false),h=harness(i),m=h.open();m.props.onAction(move);assert.equal(h.events.length,1);assert.equal(h.events[0][0],move);assert.equal(h.events[0][1],i);
});
const {PersistenceBanner}=load('persistence-banner.tsx',{'react/jsx-runtime':{jsx,jsxs:jsx}});
const persistenceObservations=['saved','save-failed','not-attempted'].map(feedback=>{let calls=0;const tree=PersistenceBanner({persistence:{feedback},onRetrySave:()=>calls++});return{feedback,actualText:text(tree),callsDuringRead:calls}});
const report={kind:'SOURCE_ISOLATION_WITH_EXPLICIT_REACT_ELEMENT_AND_HOOK_ADAPTERS',sha:'2e3d13a52ada1fdcd9848574e918b97db43cb0c2',
 scope:'Full InventoryPanel / PersistenceBanner function bodies, no React DOM renderer, actual browser, or actual P/R/S',
 total:results.length,passed:results.filter(r=>r.result==='PASS').length,failed:results.filter(r=>r.result==='FAIL').length,
 unexpected:results.filter(r=>r.unexpected).length,results,persistenceObservations};
fs.writeFileSync(path.join(root,'visual-seam-results.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));process.exitCode=report.failed?1:0;
