# ENG-WORLD-LOW-ASSET-UI-001：准确 SHA 源码阶段审查 v1.0

## 结论与当前操作

状态：**SOURCE_FINDING_CONFIRMED / VISUAL_REVIEW_PENDING**。已发现一项需修正的既有交互合同缺口；本条不是完整 UI 验收 PASS，也不是新的 Codex 执行任务书。

Owner 此刻仅需将已生成的 `ENG-WORLD-LOW-ASSET-UI-001-UI-REVIEW-ASSETS-v1.0.zip` 真正上传到当前 WebGPT 会话。当前材料只有该 ZIP 的 Windows 本地链接、作者报出的大小和 SHA-256，未取得 ZIP 字节。Codex 继续保持停止，不重新开工、不进入 Owner 首玩、不合并或发布。

待现有截图材料到齐后，将源码与视觉发现合并处理，避免把同一 UI 批次拆成多轮零散返修。本报告不要求重新生成原截图或重新运行已有任务。

## 1. 审查对象与材料

- 仓库：`lvlw/elevator-survival`。
- Commit：`2e3d13a52ada1fdcd9848574e918b97db43cb0c2`。
- Parent：`0ac23bc3654d69c3d0a6289d5d9e97ce30c69164`。
- Tree：`8673c1c7a7492756c2c686de18a268321b37668b`。
- 工程分支：`feature/world-low-asset-ui-001`，远端读取时指向上述 commit。
- Compare：本批 87 条变更，与作者交付的数量一致；未冒称读取了 Owner 本地工作区。
- 实际读取：原任务包、准确提交元数据与变更清单、入口和挂载逻辑、核心／state 输入说明、主要 UI 组件、参数表单和确认层、物品／导航／战斗／first-fit／选择失效逻辑、原生 DOM 驱动及选定测试、作者支持矩阵、有效 UIR 相关段落与 CI166 完整日志。
- 实际未取得：作者 37 件 UI 审阅包，包含 12 张截图及其原文件。因此没有独立验证 ZIP 摘要、截图内容、遮挡、实际字体可读性或视觉效果。

作者声称的审阅 ZIP SHA-256 为 `559a1ed3b8f40567934e0ce875dfe6d559b19ac39ef5487e01cf9a857ef76934`，大小 4,037,163 字节；目前只记录为待比对值，不作为已核验事实。

## 2. UI-01：主要完整行动缺少执行前只读说明入口

优先级：本批功能完整性修正，进入 Owner 首玩前处理。该编号仅属本次 UI 审查，与先前已关闭的 E03-A F01/F02 无关。

### 2.1 依据

原任务书 §3.2 明确要求：界面能够读到需要什么、实际会支付什么；§3.3 保留 L0 读取、L1 完整普通请求一次执行和 L2/L3 分级，不能套全动作通用确认。

`docs/09-ui-design-record.md` 当前有效速查及 UIR-010 要求主要行动拥有可访问的 Tooltip／Info Card／Mechanic Help，短名称不能替代来源、目标和后果说明。UIR-015 减少强制 Modal，但没有取消只读说明责任。查看说明不是执行动作的强制前置。

### 2.2 准确源码证据

1. `src/ui/infected-world/components/world-stage.tsx:21-22` 的来源和任务按钮只渲染 `actionName(action)`，并将 `onClick` 直接连接 `onAction(action)`；没有对应的焦点／悬停信息处理、描述关联、title 或就近代价信息。已读 GameShell 与 App 也未提供另一条同一行动说明通路。
2. `src/ui/infected-world/labels.ts:5` 的 `actionName` 只合成动作名与方法名，不包含资格、费用或后果。
3. `src/ui/infected-world/app.tsx:63` 在 `describeAction` 返回 `fields=[]` 时直接调用 `execute`。
4. `app.tsx:48-55` 虽调用正式 `controls.preview`，下一步立即执行 `controls.execute`。普通 committed 分支不会把得到的 metadata 呈现给玩家；只有需要确认的分支把 metadata 存入确认层。
5. `src/core/residence-supply/player-inputs.ts` 说明无照明搜索及不需要工具、材料或产出格位的部分公开任务可以产生空 fields，因此这不是只在不可达 TEST 形状上推测的分支。
6. 参数层 `action-form.tsx` 和确认层 `confirmation-layer.tsx` 已有 SafeFacts，因此缺口不是全系统没有 metadata，而是无需参数／确认的主要行动无法事先查看它。

### 2.3 玩家影响和边界

例如无需补参数的无照明搜索、调查类动作：玩家能看到动作名称，但当前这条 UI 路径不能在提交前单独查看正式的实际精力费用与已知机制。后端仍按正式规则执行；本报告没有发现因此免费执行或错误结算，也没有声称已经发生 Owner 误操作。

单边移动按钮已有精力显示，战斗部分按钮已有资源显示；不能扩大为“所有按钮都没有代价”。主线没有运行完整 React DOM 或浏览器，这一判断来源是准确源码与下面的隔离控制流检查。

### 2.4 修正边界（方向，不是开工任务）

保留 L1 一次明确点击执行。补一条真实、可访问的 L0 只读说明路径，例如锚定 Hover／Focus 信息、按需详情入口或就地说明；具体呈现可选，不能把所有动作变成强制确认。

完整请求采用当前正式 preview／inspect 的费用、支付与已公开机制；参数未齐时只说明缺少的必要输入。不得在 React 中硬编码费用、读取 raw state、试跑 producer 或推断隐藏结果。过期选择和状态变化必须失效，查看／关闭说明仍零 dispatch、零写入、零随机。

原生补验应让真实 UI 进入稳定房间，在不执行动作的前提下通过鼠标与键盘访问上述信息，并与正式安全接口对照；随后明确点击应只有一次实际提交。用例须接受不同合法的只读呈现方式，不把本报告使用的事件属性检查变成唯一 UI 实现要求。

## 3. 已核对且保留的工程证据

### 3.1 入口隔离

`src/app/application-entry.ts` 保留旧 DEV preview 优先级；非 DEV 始终走 production。`src/main.tsx` 的新世界分支位于医院存储与 bootstrap 创建之前，医院模块在其分支才初始化。主线独立执行入口纯函数正反例，见 evidence。

这不能替代完整生产 bundle 或浏览器副作用复验，但没有在所读入口代码发现同时创建两套 owner 的路径。

### 3.2 真实 DOM 长链

`src/ui/infected-world/route-test-fixtures.ts` 实际通过按钮 click、select/input 的 DOM 事件和格位按钮推进；并非直接调用 owner.execute 代替 UI。主线阅读了驱动与路线；CI166 也实际执行了 A/B DOM 集成测试。

源码可达路线不等于新玩家能理解每个动作，也不等于 Owner 体验通过。两条成功／止损链的成果保留，不因 UI-01 推翻。

### 3.3 选择与 first-fit

所读选择检查按 opaque 引用验证当前动作、对象、材料、分配和伤口，不按名称静默替换。first-fit 按未旋转 y→x 逐格调用正式接口，只接 available，不把 unknown 当作合法位置。

主线针对这些函数运行了 TEST 输入／回调下的隔离检查；并没有独立重跑正式背包资格或完整 P/R/S。

## 4. 主线实际执行

### 4.1 六份源码指纹

从工具取得的六份完整模块复制到本地后逐件重算 Git blob，均与准确提交匹配：App、WorldStage、labels、application-entry、first-fit、interaction。详见 `evidence/source-integrity.json`。

### 4.2 二十七项源码隔离检查

`evidence/check-ui-boundaries.cjs` 使用 TypeScript 转译准确源文件：

- 7 项入口分流；
- 5 项 first-fit 选择与不修改输入；
- 8 项 opaque 选择及失效；
- 5 项 App 调用次序、参数／确认分流与单飞；
- 2 项 WorldStage 来源／任务按钮只读信息入口检查。

实际：**25 项符合，2 项信息入口断言失败，0 非预期程序异常；exit 1**。两项失败属于同一个 UI-01，而非两个独立缺陷。

React hooks、JSX element factory、子组件、owner/control、公开 TEST 状态及 first-fit Preview 使用明确适配器；没有真正挂载 React、运行浏览器或执行 P/R/S。该检查证明的是局部源码路径与输出结构，不是完整浏览器体验。具体代码阅读是“当前没有其他说明入口”的补充依据，不能仅凭缺少某一个 onFocus 属性泛化出所有 UI 方案失败。

仓库外负控：去掉 production guard，新增加 E02/E03 两项断言失败；将 opaque 引用比较改为值相等，新增加两项选择断言失败。原有两个 UI-01 失败仍然存在，不将其重复算作负控检出。各负控总计 4 失败，新增有效检出分别为 2；无导入／类型／fixture 错误。

### 4.3 原任务输入

本地原 ZIP 的六件输入逐件 Git blob、五条 SHA-256 和完整 tree 重算后，与准确提交 inputs tree `987e8a3553beac15d5f53dbe565c11e8af432586` 一致。这里不是对作者 1627 个保护对象的完整复跑。

## 5. CI166 与维护告警

准确运行：39824201411；job：119983034191；head 为受审 SHA；completed/success。

主线读取完整 job 日志：53 DEC／347 core production files；309 个测试文件、4650 项全部通过，test 阶段 295.99 秒；typecheck 与 build 成功。摘记保留在 `evidence/ci166-log-review.json`，明确是摘记，不冒充完整原日志。

同一日志 npm ci 报 6 项依赖摘要告警（2 moderate／4 high）。作者本机 audit 镜像 API 404 是另一条历史证据。当前没有取得该告警的包级详情、可达性或适用性分析，不能声称依赖安全、不能依据摘要判断具体游戏漏洞，也不在本轮顺带升级依赖。

## 6. 验证未完成与停止点

- 未收到并查看 UI review ZIP；12 张截图的视觉实审：PENDING。
- 本容器取得完整仓库失败于 GitHub DNS，因此没有独立全量 npm／实际 React DOM／Edge／localStorage／多标签复跑。
- 作者的 96 项新增测试、两条 DOM 路线、7 组 Edge、T02 24 项及视觉自查，继续按作者证据记录，不转写为主线执行。
- W01／W02未扩大；本轮主线未完整独立复跑累计 diff-check。
- 不关闭 Owner 体验、O3、公开发布、旧槽安排、其他浏览器或最终美术／音频 Gate。

**当前唯一 Owner 操作：上传已经存在的截图审阅 ZIP 到本 WebGPT 会话。Codex 不用重新运行、不用重建 ZIP、不用执行本报告。**
