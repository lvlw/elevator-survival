// Independent source-isolation review. This is NOT React DOM, P/R/S or browser execution.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
const mutation = process.argv[2] || 'none';
const out = process.argv[3] || path.join(__dirname, 'ui-boundary-results.json');
const inventory = JSON.parse(fs.readFileSync(path.join(__dirname,'source-integrity.json'),'utf8'));
for (const entry of inventory) {
  const b = fs.readFileSync(path.join(root,'source',entry.file));
  const blob = crypto.createHash('sha1').update(Buffer.concat([Buffer.from(`blob ${b.length}\0`),b])).digest('hex');
  assert.equal(blob,entry.expected,`source integrity: ${entry.file}`);
}
function load(file, deps = {}) {
  let source = fs.readFileSync(path.join(root,'source',file),'utf8');
  if (mutation === 'remove-production-guard' && file === 'application-entry.ts')
    source = source.replace("if (!input.isDevelopment) return 'production'", '// TEST negative control: guard removed');
  if (mutation === 'accept-cloned-action' && file === 'interaction.ts')
    source = source.replace('a.selector === request.action', 'JSON.stringify(a.selector) === JSON.stringify(request.action)');
  const transformed = ts.transpileModule(source, {fileName:file, compilerOptions:{module:ts.ModuleKind.CommonJS,
    target:ts.ScriptTarget.ES2022, jsx:ts.JsxEmit.ReactJSX, isolatedModules:true}}).outputText;
  const module = {exports:{}};
  const req = name => {
    if (!Object.prototype.hasOwnProperty.call(deps,name)) throw new Error('Unexpected adapter import '+name+' in '+file);
    return deps[name];
  };
  const fn = vm.runInThisContext(`(function(require,module,exports){${transformed}\n})`, {filename:file});
  fn(req,module,module.exports); return module.exports;
}
const results = [];
function test(id,scope,expected,fn) {
  try { fn(); results.push({id,scope,expected,result:'PASS'}); }
  catch(e) { results.push({id,scope,expected,result:'FAIL',kind:e instanceof assert.AssertionError?'AssertionError':'UNEXPECTED_ERROR',message:e.message}); }
}
const entry=load('application-entry.ts'),fit=load('first-fit.ts'),inter=load('interaction.ts');
const marker=()=>Object.freeze({selection:'opaque'});
const action=(family,label,method=null)=>Object.freeze({selector:marker(),family,label,method,availability:'available',cost:null});
function viewFor(a){return {status:'ready',phase:'active-world',point:'stable-active',location:{name:'大厅',place:'医院'},actions:[a],
  sources:[],tasks:{choices:[],publicObjectives:[]},move:{options:[]},carried:[],ground:[],body:{wounds:[]},combat:null,backpack:{width:6,height:4}};}
const entries=[
 ['E01',false,'','production'], ['E02',false,'?dev-infected-world=1','production'],
 ['E03',false,'?dev-ui-preview=1','production'], ['E04',true,'','production'],
 ['E05',true,'?dev-infected-world=1','infected-world-playtest'],
 ['E06',true,'?dev-ui-preview=1','development-preview'],
 ['E07',true,'?dev-infected-world=1&dev-ui-preview=1','development-preview']
];
for(const[id,isDevelopment,search,want]of entries)test(id,'actual pure entry function',want,()=>assert.equal(entry.selectApplicationEntry({isDevelopment,search}),want));
test('P01','actual firstFit + deterministic TEST preview','row-major stops at first legal',()=>{
 const seen=[]; const p=fit.firstFit(3,2,{action:marker()},r=>{seen.push([r.placement.x,r.placement.y]);return{qualification:{kind:r.placement.x===1?'available':'unavailable'}}});
 assert.deepEqual(p,{x:1,y:0,rotated:false});assert.deepEqual(seen,[[0,0],[1,0]]);
});
test('P02','actual firstFit + deterministic TEST preview','never rotates and visits full grid',()=>{
 const seen=[];fit.firstFit(2,2,{action:marker()},r=>{seen.push(r.placement);return{qualification:{kind:'unavailable'}}});
 assert.deepEqual(seen,[{x:0,y:0,rotated:false},{x:1,y:0,rotated:false},{x:0,y:1,rotated:false},{x:1,y:1,rotated:false}]);
});
test('P03','actual firstFit + deterministic TEST preview','unavailable is not placement',()=>assert.equal(fit.firstFit(1,1,{action:marker()},()=>({qualification:{kind:'unavailable'}})),null));
test('P04','actual firstFit + deterministic TEST preview','unknown is not legal placement',()=>assert.equal(fit.firstFit(1,1,{action:marker()},()=>({qualification:{kind:'unknown'}})),null));
test('P05','actual firstFit + deterministic TEST preview','caller request unchanged',()=>{
 const request={action:marker(),item:marker()},before=JSON.stringify(request);fit.firstFit(2,2,request,()=>({qualification:{kind:'available'}}));
 assert.equal(JSON.stringify(request),before);assert.equal('placement'in request,false);assert.equal(Object.isFrozen(request),false);
});
for(const mode of ['live','cloned-action','replaced-action','cloned-target','stale-material','stale-allocation','cloned-wound','new-phase']) {
 test('S-'+mode,'actual requestStillVisible + TEST opaque references',mode==='live'?'accept':'reject',()=>{
  const a=action('task','TEST'),v=viewFor(a),i=marker(),t=marker(),w=marker();v.carried=[{selector:i},{selector:t}];v.body.wounds=[{selector:w}];
  const r={action:a.selector,item:i,targetItem:t,wound:w,materials:[{item:i,quantity:1}],allocations:[{item:t,amount:1}]};
  if(mode==='cloned-action')r.action={selection:'opaque'};
  if(mode==='replaced-action')v.actions=[action('task','TEST')];
  if(mode==='cloned-target')r.targetItem={selection:'opaque'};
  if(mode==='stale-material')r.materials=[{item:marker(),quantity:1}];
  if(mode==='stale-allocation')r.allocations=[{item:marker(),amount:1}];
  if(mode==='cloned-wound')r.wound=marker();
  if(mode==='new-phase'){v.phase='living-hub';v.actions=[];}
  assert.equal(inter.requestStillVisible(v,r),mode==='live');
 });
}
const jsx = (type,props,key) => ({type,props:props||{},key});
const names=['GameShell','SetupPanel','SystemScreen','ActionForm','ConfirmationLayer','BattleStage','HubPanel','TerminalPanel','TravelCluster','KnowledgeMap'];
const components=Object.fromEntries(names.map(name=>[name,Object.assign(function(){},{displayName:name})]));
function nodes(tree) {
 if(tree==null||typeof tree==='boolean')return [];
 if(Array.isArray(tree))return tree.flatMap(nodes);
 if(typeof tree!=='object')return [];
 return [tree,...nodes(tree.props?.children)];
}
function text(tree){if(tree==null||typeof tree==='boolean')return '';if(Array.isArray(tree))return tree.map(text).join('');if(typeof tree!=='object')return String(tree);return text(tree.props?.children);}
function appHarness(a,fields=[],executeKind='committed') {
 const v=viewFor(a),events=[],stateWrites=[],microtasks=[];
 const metadata={qualification:{kind:'available',cost:12},death:{kind:'not-guaranteed'},facts:{mechanisms:['TEST public action explanation'],resources:[]}};
 const controls={describeAction:()=>{events.push('describe');return{fields}},preview:()=>{events.push('preview');return metadata},
   execute:()=>{events.push('execute');return{kind:executeKind,...(executeKind==='confirmation-required'?{confirmation:{confirmation:'preplay'}}:{})}}};
 const hook={owner:{controls:()=>controls},snapshot:{status:'ready',preplay:{status:'stable',view:v,feed:[]}}};
 const deps={react:{useState:initial=>[initial,x=>stateWrites.push(x)],useRef:x=>({current:x}),useEffect:()=>{}},
   'react/jsx-runtime':{jsx,jsxs:jsx},
   '../../app/infected-browser/errors':{BrowserOwnerError:class extends Error{}},
   '../../state/residence-session/player-errors':{isPlayerBusinessError:()=>false},
   './use-browser-owner':{useBrowserOwner:()=>hook},'./interaction':inter,'./first-fit':fit,'./styles.css':{}};
 for(const n of ['GameShell','SetupPanel','SystemScreen','ActionForm','ConfirmationLayer']){
   const f=n.replace(/[A-Z]/g,(s,i)=>(i?'-':'')+s.toLowerCase());deps['./components/'+f]={[n]:components[n]};
 }
 const mod=load('app.tsx',deps),tree=mod.InfectedWorldApp({});
 const shell=nodes(tree).find(n=>n.type===components.GameShell);assert.ok(shell);
 return{view:v,events,stateWrites,metadata,controls,tree,shell};
}
test('A01','actual app function + explicit React/owner adapters','complete request is previewed then immediately executed',()=>{
 const a=action('source','大厅搜索','dark'),h=appHarness(a);h.shell.props.onAction(a);
 assert.deepEqual(h.events,['describe','preview','execute']);assert.equal(h.stateWrites.some(x=>x&&typeof x==='object'&&'metadata'in x),false);
});
test('A02','actual app function + explicit React/owner adapters','missing parameters create draft without execution',()=>{
 const a=action('task','提取样本','cautious'),h=appHarness(a,['placement']);h.shell.props.onAction(a);
 assert.deepEqual(h.events,['describe']);assert.ok(h.stateWrites.some(x=>x&&x.action===a&&x.controls===h.controls));
});
test('A03','actual app function + explicit React/owner adapters','stale complete selection does not execute',()=>{
 const a=action('source','大厅搜索','dark'),h=appHarness(a);h.view.actions=[];h.shell.props.onAction(a);
 assert.deepEqual(h.events,['describe']);assert.ok(h.stateWrites.includes('选择已失效，请重新选择。'));
});
test('A04','actual app function + explicit React/owner adapters','same synchronous click window is single-flight',()=>{
 const a=action('source','大厅搜索','dark'),h=appHarness(a);h.shell.props.onAction(a);h.shell.props.onAction(a);
 assert.deepEqual(h.events,['describe','preview','execute']);
});
test('A05','actual app function + explicit React/owner adapters','protected intent retains metadata for confirmation',()=>{
 const a=action('terminal','失败止损返回'),h=appHarness(a,[],'confirmation-required');h.shell.props.onAction(a);
 assert.ok(h.stateWrites.some(x=>x&&x.metadata===h.metadata&&x.title===a.label));
});
const catalog={methods:{dark:'无照明搜索',manual:'手动处理'},tools:[],specialties:[]};
const labels=load('labels.ts',{'../../content/infected-world-v0.1/player-ui-catalog':{infectedWorldUiCatalog:catalog}});
const stageDeps={'react':{useState:x=>[x,()=>{}],useEffect:()=>{}},'react/jsx-runtime':{jsx,jsxs:jsx},
 '../assets':{roomImage:()=>null},'../labels':labels};
for(const n of ['BattleStage','HubPanel','TerminalPanel','TravelCluster','KnowledgeMap']){
 const f=n.replace(/[A-Z]/g,(s,i)=>(i?'-':'')+s.toLowerCase());stageDeps['./'+f]={[n]:components[n]};
}
const WorldStage=load('world-stage.tsx',stageDeps).WorldStage;
const sources=action('source','大厅搜索','dark'),task=action('task','调查供电');
const stageView=viewFor(task);stageView.actions=[];stageView.sources=[{label:'大厅搜索',completed:false,choices:[sources]}];stageView.tasks.choices=[task];stageView.map={nodes:[],routes:[]};
const stage=WorldStage({view:stageView,onAction:()=>{}});
for(const[id,a]of [['F01-source',sources],['F01-task',task]]) {
 test(id,'actual WorldStage element tree + inert child adapters','read-only pre-action information route exists (REQUIRED; currently absent)',()=>{
   const button=nodes(stage).find(n=>n.type==='button'&&text(n)===labels.actionName(a));assert.ok(button,'target button exists');
   const props=button.props,hasInformation=['onFocus','onPointerEnter','onMouseEnter','aria-describedby','aria-details','title'].some(k=>props[k]!=null);
   assert.ok(hasInformation,'Button exposes only label/method and execution onClick, with no described information or read-only trigger; external help also absent in inspected App/GameShell.');
 });
}
const report={kind:'SOURCE_ISOLATION_NOT_NATIVE_REACT_NOT_BROWSER',head:'2e3d13a52ada1fdcd9848574e918b97db43cb0c2',mutation,
 adapters:['React initial hooks/element factory only; no rendering/effects/event system','inert child-component tokens','TEST public view, controls and metadata; not real P/R/S','TEST preview for first-fit, not formal qualifier','approved public method labels copied as TEST vocabulary'],
 total:results.length,passed:results.filter(r=>r.result==='PASS').length,failed:results.filter(r=>r.result==='FAIL').length,
 unexpectedErrors:results.filter(r=>r.kind==='UNEXPECTED_ERROR').length,results};
fs.writeFileSync(out,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({mutation,total:report.total,passed:report.passed,failed:report.failed,unexpectedErrors:report.unexpectedErrors,failures:results.filter(r=>r.result==='FAIL').map(r=>r.id)},null,2));
process.exitCode=report.failed?1:0;
