"""通信中心候选的逐行动纸面账。不是正式Scene/物品实例/存档实现。
支持固定候选地图、指定物资的显式位置、库存来源不重复兑现、初次遭遇、
零时间拾取、0时间禁用与真实节点强制返程；不支持跨日来源/敌人重置。
"""
from __future__ import annotations
from copy import deepcopy
from fractions import Fraction
from math import ceil
from paper_combat import encounter

NAMES={'E':'电梯入口','H':'接待大厅','D':'值班室','A':'调度档案室','P':'设备通道','R':'应急装置间'}
EDGES=(('E','H'),('H','D'),('H','A'),('H','P'),('P','R'))
# 当地表层明确发现；不是通过旧Scene或Run日志自动补全空间。
OBSERVE={'E':(('E','H'),),'H':(('H','D'),('H','A'),('H','P')),
         'D':(),'A':(),'P':(('P','R'),),'R':()}
# 仅纸面命名，一次性来源中的实际单位；不冒充生产ItemInstance ID。
ITEMS={
 'module':dict(name='应急启动模块（候选）',weight=2,w=1,h=2,x=0,y=0,source='module-device'),
 'metal':dict(name='金属零件',weight=1,w=1,h=1,x=1,y=0,source='cabinet'),
 'electronic':dict(name='电子元件',weight=1,w=1,h=1,x=2,y=0,source='cabinet'),
 'battery':dict(name='通用电池',weight=1,w=1,h=1,x=3,y=0,source='cabinet'),
 'ration':dict(name='口粮',weight=1,w=1,h=1,x=4,y=0,source='duty-search'),
}

def route_actions(*,materials:bool=True,food:bool=False,late_cabinet:bool=False,
                  heal_after_combat:bool=False,escape:bool=False) -> tuple[tuple[str,str],...]:
    ops=[('move','H')]
    if materials and not late_cabinet:
        ops += [('move','D'),('cabinet',''),('pickup','metal'),('pickup','electronic'),('pickup','battery')]
        if food:ops += [('search-food',''),('pickup','ration')]
        ops += [('move','H')]
    ops += [('gate',''),('move','P'),('combat','')]
    if escape:
        return tuple(ops+[('move','E')])
    if heal_after_combat:ops.append(('bandage',''))
    ops += [('move','R'),('match',''),('extract',''),('move','P'),('move','H')]
    if materials and late_cabinet:
        ops += [('move','D'),('cabinet',''),('pickup','metal'),('pickup','electronic'),('pickup','battery')]
        if food:ops += [('search-food',''),('pickup','ration')]
        ops += [('move','H')]
    ops.append(('move','E'))
    return tuple(ops)


def run_route(ops:tuple[tuple[str,str],...],combat_actions:tuple[str,...],*,hp:int=4,
              durability:int=6,coat:int=4,crowbar:int=3,bandages:int=1,
              injury_hits:frozenset[int]=frozenset(),exposure_hits:frozenset[int]=frozenset(),
              initial_contusion:bool=False,interface_known:bool=True,
              cabinet_used:bool=False,manual_obstacles:bool=False) -> dict:
    if not(0<hp<=12 and 0<=crowbar<=3):raise ValueError('Invalid Scene input')
    remaining=200;position='E';gate=False;danger=True;matched=False
    bleeding=False;contusion=initial_contusion;wounds=[];pending_exposure=0
    packed={};revealed={};search_used=False;module_extracted=False
    known={tuple(sorted(e)) for e in OBSERVE['E']}
    records=[];combat_result=None;outcome='script-ended'
    forced_loss=forced_debt=forced_distance=0;failure_reason=None
    total_charged_time=0

    def pack_weight():return sum(ITEMS[k]['weight'] for k in packed)
    def movement_cost():
        weight=pack_weight()
        if weight>=29:raise ValueError('Cannot-carry inventory')
        load=Fraction(1) if weight<=16 else Fraction(11,10) if weight<=24 else Fraction(5,4)
        injury=Fraction(11,10) if contusion else Fraction(1)
        return ceil(10*load*injury)
    def add_item(key:str):
        if key in packed:raise ValueError('Duplicate paper item')
        item=ITEMS[key]; occupied=set()
        for other in packed.values():
            occupied|={(x,y) for x in range(other['x'],other['x']+other['w']) for y in range(other['y'],other['y']+other['h'])}
        cells={(x,y) for x in range(item['x'],item['x']+item['w']) for y in range(item['y'],item['y']+item['h'])}
        if any(x<0 or y<0 or x>=6 or y>=4 for x,y in cells) or cells&occupied:
            raise ValueError('Illegal specified placement')
        if pack_weight()+item['weight']>=29:raise ValueError('Cannot carry item')
        packed[key]=deepcopy(item)
    def back_distance():
        queue=[(position,0)];seen=set()
        while queue:
            node,cost=queue.pop(0)
            if node=='E':return cost
            if node in seen:continue
            seen.add(node)
            for a,b in EDGES:
                if tuple(sorted((a,b))) not in known:continue
                if {a,b}=={'H','P'} and not gate:continue
                if {a,b}=={'P','R'} and danger:continue
                target=b if a==node else a if b==node else None
                if target is not None and target not in seen:queue.append((target,cost+movement_cost()))
        raise ValueError('No legal known return route')
    for i,(action,target) in enumerate(ops):
        if outcome!='script-ended':break
        if remaining<=0:
            raise ValueError('Ordinary action cannot start at zero')
        if position=='P' and danger and action!='combat':raise ValueError('Pending encounter must be resolved')
        cost=0;before=remaining;before_hp=hp;note=''
        if action=='move':
            edge=tuple(sorted((position,target)))
            if edge not in known:raise ValueError('Unknown or nonadjacent edge')
            if set(edge)=={'H','P'} and not gate:raise ValueError('Gate closed')
            if set(edge)=={'P','R'} and danger:raise ValueError('Danger blocks deeper route')
            cost=movement_cost();position=target
            known.update(tuple(sorted(e)) for e in OBSERVE[position])
        elif action=='gate':
            if position!='H' or gate:raise ValueError('Invalid gate operation')
            if manual_obstacles:cost=40
            else:
                if crowbar<=0:raise ValueError('Crowbar unavailable')
                crowbar-=1;cost=20
            gate=True
        elif action=='cabinet':
            if position!='D' or cabinet_used:raise ValueError('Cabinet unavailable')
            if manual_obstacles:cost=40
            else:
                if crowbar<=0:raise ValueError('Crowbar unavailable')
                crowbar-=1;cost=20
            cabinet_used=True
            for key in ('metal','electronic','battery'):revealed[key]=True
        elif action=='search-food':
            if position!='D' or search_used:raise ValueError('Search unavailable')
            cost=30;search_used=True;revealed['ration']=True
        elif action=='pickup':
            if position!='D' or target not in revealed:raise ValueError('No revealed item here')
            add_item(target);del revealed[target]
        elif action=='combat':
            if position!='P' or not danger:raise ValueError('No pending encounter')
            combat_result=encounter(combat_actions,hp=hp,durability=durability,coat=coat,bandages=bandages,
                                    injury_hits=injury_hits,exposure_hits=exposure_hits,
                                    initial_bleeding=bleeding,initial_contusion=contusion)
            hp=combat_result['hp'];durability=combat_result['durability'];coat=combat_result['coat']
            bleeding=combat_result['bleeding'];contusion=combat_result['contusion'];wounds=combat_result['wounds']
            bandages=combat_result['bandages'];pending_exposure+=combat_result['pending_exposure']
            cost=combat_result['scene_time']
            if combat_result['outcome']=='victory':danger=False
            elif combat_result['outcome']=='escaped':position='H'
            elif combat_result['outcome']=='dead':outcome='dead';failure_reason='combat-health-depleted'
            else:raise ValueError('Combat script incomplete')
        elif action=='bandage':
            if bandages<=0 or (hp==12 and not bleeding and all(w['treated'] for w in wounds)):
                raise ValueError('Bandage unavailable')
            cost=10;bandages-=1;hp=min(12,hp+1);bleeding=False
            for w in wounds:
                if not w['treated']:w['treated']=True;break
        elif action=='match':
            if position!='R' or danger or matched or not interface_known:raise ValueError('Matching unavailable')
            cost=10;matched=True
        elif action=='extract':
            if position!='R' or danger or not matched or module_extracted:raise ValueError('Extraction unavailable')
            # 独立任务提取的显式placement在行动前已由add_item检查；同一行动进入背包。
            cost=20;add_item('module');module_extracted=True
        else:raise ValueError(f'Unknown action: {action}')
        debt=max(0,cost-before);remaining=max(0,before-cost);total_charged_time+=cost
        if action!='combat' and cost>0 and bleeding and hp>0:hp-=1
        if hp==0:outcome='dead';failure_reason=failure_reason or 'post-action-bleeding'
        if outcome!='dead':
            if position=='E' and debt==0:
                outcome='safe-returned'  # 最后一条边恰好归零，没有额外伤害。
            elif remaining==0:
                forced_debt=debt;forced_distance=back_distance()
                forced_loss=min(4,ceil((debt+forced_distance)/20))+(1 if bleeding and debt+forced_distance>0 else 0)
                hp=max(0,hp-forced_loss)
                outcome='forced-returned' if hp>0 else 'dead'
                if hp==0:failure_reason='forced-return-health-depleted'
                else:position='E'
                note='forced-return-resolved'
        records.append(dict(action=action,target=target,position=NAMES[position],time_cost=cost,
                            remaining=remaining,hp_before=before_hp,hp_after=hp,crowbar=crowbar,
                            weapon=durability,coat=coat,bleeding=bleeding,contusion=contusion,
                            pending_exposure=pending_exposure,packed=list(packed),revealed=list(revealed),
                            debt=debt,outcome=outcome,note=note))
    safe=outcome in ('safe-returned','forced-returned')
    returned=list(packed) if safe else []
    return dict(outcome=outcome,hp=hp,remaining=remaining,position=NAMES[position],
                durability=durability,coat=coat,crowbar=crowbar,bandages=bandages,
                bleeding=bleeding,contusion=contusion,wounds=wounds,pending_exposure=pending_exposure,
                carried_items=list(packed),safely_returned_items=returned,revealed_left=list(revealed),
                pack_weight=pack_weight(),task_module_safely_returned='module' in returned,
                current_visit_installation_materials=all(k in returned for k in ('metal','electronic')),
                actual_scene_cost=total_charged_time,forced_loss=forced_loss,forced_debt=forced_debt,
                forced_distance=forced_distance,failure_reason=failure_reason,events=records,
                combat=combat_result)
