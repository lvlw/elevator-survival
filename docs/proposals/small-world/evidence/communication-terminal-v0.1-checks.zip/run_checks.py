"""运行方式：python run_checks.py。
仅核算明确候选和指定分支。不访问仓库、不读取/写入玩家存档，非正式测试。
"""
from __future__ import annotations
import json
from dataclasses import asdict
from pathlib import Path
from paper_combat import encounter, COMMUNICATION, LOGISTICS
from paper_scene import route_actions, run_route

COMBO=('basic','defend','charged','basic','basic')
LATE_COMBO=('basic','defend','basic','charged','basic')
DEFEND=('basic','defend','basic','basic','basic')
COMBAT_HEAL=('basic','defend','basic','bandage','basic','basic')
LATE_HEAL=('basic','defend','charged','basic','bandage','basic')
LOW_DUR=('basic','defend','basic','charged','temporary')

CASES={
 'combo_hp4_no_exposure':dict(actions=COMBO),
 'combo_hp4_exposure':dict(actions=COMBO,exposure_hits=frozenset({2})),
 'charge_at_280':dict(actions=LATE_COMBO),
 'basics_hp12':dict(actions=('basic',)*4,hp=12),
 'basics_hp8_wound_exposure':dict(actions=('basic',)*4,hp=8,injury_hits=frozenset({2}),exposure_hits=frozenset({2})),
 'defense_hp12':dict(actions=DEFEND,hp=12),
 'defense_hp4_dies':dict(actions=DEFEND),
 'hospital_combo_hp12':dict(actions=('basic','charged','basic','basic'),hp=12),
 'combo_hp3_dies':dict(actions=COMBO,hp=3),
 'coat_one_hp4_dies':dict(actions=COMBO,coat=1),
 'durability_three_last_temporary':dict(actions=LOW_DUR,durability=3),
 'durability_four_last_temporary':dict(actions=LOW_DUR,durability=4),
 'durability_five_last_temporary':dict(actions=LOW_DUR,durability=5),
 'late_bandage_hp4':dict(actions=LATE_HEAL),
 'bandage_at_280_no_charge':dict(actions=COMBAT_HEAL),
 'immediate_escape_hp4':dict(actions=('escape',)),
 'pretreated_hp5_defense':dict(actions=DEFEND,hp=5,bandages=0),
 'logistics_control_recheck':dict(actions=DEFEND,enemy=LOGISTICS,hp=6),
}
# outcome, CTB, 场景时间, HP, 剩余武器, 剩余外套, 绷带, 流血, 未结算暴露
EXPECT={
 'combo_hp4_no_exposure':('victory',460,50,1,0,2,1,False,0),
 'combo_hp4_exposure':('victory',460,50,1,0,2,1,False,1),
 'charge_at_280':('victory',460,50,1,0,2,1,False,0),
 'basics_hp12':('victory',300,30,7,2,2,1,False,0),
 'basics_hp8_wound_exposure':('victory',300,30,1,2,2,1,True,1),
 'defense_hp12':('victory',380,40,8,2,1,1,False,0),
 'defense_hp4_dies':('dead',350,40,0,3,1,1,False,0),
 'hospital_combo_hp12':('victory',380,40,7,0,2,1,False,0),
 'combo_hp3_dies':('dead',170,20,0,5,2,1,False,0),
 'coat_one_hp4_dies':('dead',170,20,0,5,0,1,False,0),
 'durability_three_last_temporary':('victory',460,50,1,0,2,1,False,0),
 'durability_four_last_temporary':('victory',460,50,1,0,2,1,False,0),
 'durability_five_last_temporary':('victory',460,50,1,0,2,1,False,0),
 'late_bandage_hp4':('victory',540,60,1,0,1,0,False,0),
 'bandage_at_280_no_charge':('victory',460,50,1,2,1,0,False,0),
 'immediate_escape_hp4':('escaped',80,10,3,6,3,1,False,0),
 'pretreated_hp5_defense':('victory',380,40,1,2,1,0,False,0),
 'logistics_control_recheck':('victory',380,40,3,2,3,1,False,0),
}
KEYS=('outcome','ctb','scene_time','hp','durability','coat','bandages','bleeding','pending_exposure')


def check_economy() -> dict:
    """只复核已明确的无伤势、无感染过夜分支；最后一天不执行夜间步骤。"""
    def night(hp,satiety,rations,consume_food):
        if consume_food:
            assert rations>0 and satiety<6
            satiety=min(6,satiety+2);rations-=1
        satiety=max(0,satiety-2)
        if satiety<=1:hp=max(0,hp-1);recovery=0
        else:recovery=2 if satiety>=4 else 1
        if hp==0:return hp,satiety,rations
        return min(12,hp+recovery),satiety,rations
    def logi(hp):
        r=encounter(DEFEND,enemy=LOGISTICS,hp=hp)
        assert r['outcome']=='victory' and not r['bleeding'] and not r['contusion']
        return r['hp']
    only=night(logi(6),4,0,False)
    all_loot=night(logi(6)-1,4,3,True)
    assert only==(4,2,0) and all_loot==(4,4,2)
    # 只取件：Day2工时3修武器2->5；Day3工时3分别补武器/外套/撬棍。
    only_repaired=(2+3+1,3+1,2+1)
    assert only_repaired==(6,4,3)
    # 带齐：用物流来源金属1的5点给武器4、撬棍1；当晚工时1补外套。
    all_repaired=(2+4,3+1,2+1)
    assert all_repaired==(6,4,3) and 4+1==5
    c_day3=run_route(route_actions(),COMBO,hp=only[0])
    c_full_day3=run_route(route_actions(),COMBO,hp=all_loot[0])
    assert c_day3['hp']==c_full_day3['hp']==1
    assert c_day3['current_visit_installation_materials'] and c_full_day3['current_visit_installation_materials']
    # 标准路线：Day2通信口粮，Day3物流三口粮并消费一份，Day4终段。
    day3=night(6,4,1,True)
    assert day3==(8,4,0)
    day4=night(logi(day3[0]),day3[1],day3[2]+3,True)
    assert day4==(7,4,2)
    standard=run_route(route_actions(materials=False),COMBO,hp=day4[0],cabinet_used=True)
    assert standard['hp']==4 and standard['task_module_safely_returned']
    # 恢复路线：Day2物流前区补给，新绷带+1/口粮；Day3通信；Day4物流；Day5终段。
    recovery_day3=night(6+1,4,2,True)
    recovery_day4=night(recovery_day3[0],recovery_day3[1],recovery_day3[2]+1,True)
    recovery_day5=night(logi(recovery_day4[0]),recovery_day4[1],recovery_day4[2]+3,True)
    assert recovery_day3==(9,4,1) and recovery_day4==(11,4,1) and recovery_day5==(10,4,3)
    recovery=run_route(route_actions(materials=False),COMBO,hp=recovery_day5[0],cabinet_used=True)
    assert recovery['hp']==7
    # 终局材料只消费实际存在的两份单位。标准/恢复来自先前通信；紧凑来自本次。
    for r in (c_day3,c_full_day3):
        units=list(r['safely_returned_items'])
        units.remove('metal');units.remove('electronic')
        assert set(units)=={'battery','module'}
    return dict(
        method='指定无流血/无感染过夜算例，非完整世界/存档模拟',
        compact_task_only=dict(day=3,hp=1,satiety=2,rations=0,bandages=1,day3_labor_before_exploration=0),
        compact_full_logistics=dict(day=3,hp=1,satiety=4,rations=2,bandages=1,day3_labor_before_exploration=3),
        standard=dict(day=4,hp=4,satiety=4,rations=2,bandages=1),
        recovery_first=dict(day=5,hp=7,satiety=4,rations=3,bandages=1),
        caveats=['样本/组件安全入库沿用条件性起点；未模拟医院首日与实际生成',
                 '既有材料来源用尽、跨日事实仍是候选，算账未证明生产所有权',
                 '所有终局没有追加过夜；出发后终段实际消耗与返回来自paper_scene',
                 '不合并HP与感染；主参照允许终段暴露有/无两分支但随后立即离开'])


def main():
    combats={}
    for name,kwargs in CASES.items():
        r=encounter(**kwargs)
        assert tuple(r[k] for k in KEYS)==EXPECT[name],(name,{k:r[k] for k in KEYS},EXPECT[name])
        combats[name]=r
    route_cases={
        'first_visit_exact_zero':(dict(),COMBO,dict()),
        'first_visit_exposure_preserved':(dict(),COMBO,dict(exposure_hits=frozenset({2}))),
        'prepared_terminal':(dict(materials=False),COMBO,dict(hp=7,cabinet_used=True)),
        'pre_hub_bandage_then_defense':(dict(),DEFEND,dict(hp=5,bandages=0)),
        'heal_in_fight_instead_of_charge':(dict(),COMBAT_HEAL,dict()),
        'late_heal_extends_battle_and_dies_on_return':(dict(),LATE_HEAL,dict()),
        'scene_bandage_after_combo':(dict(heal_after_combat=True),COMBO,dict()),
        'also_take_ration_hp4_dies':(dict(food=True),COMBO,dict()),
        'also_take_ration_hp6_returns':(dict(food=True),COMBO,dict(hp=6)),
        'search_ration_last_revealed_not_picked':(dict(food=True,late_cabinet=True),COMBO,dict(hp=6)),
        'retreat_with_materials_no_module':(dict(escape=True),('escape',),dict()),
        'existing_contusion_hp4_dies':(dict(),COMBO,dict(initial_contusion=True)),
        'existing_contusion_hp5_returns':(dict(),COMBO,dict(initial_contusion=True,hp=5)),
        'manual_first_visit_hp4_dies':(dict(),COMBO,dict(manual_obstacles=True)),
        'manual_prepared_hp7_returns':(dict(materials=False),COMBO,dict(manual_obstacles=True,hp=7,cabinet_used=True)),
        'durability_three_first_visit':(dict(),LOW_DUR,dict(durability=3)),
        'materials_taken_after_module':(dict(late_cabinet=True),COMBO,dict()),
        'wound_after_basic_then_scene_bandage':(dict(heal_after_combat=True),('basic',)*4,dict(hp=8,injury_hits=frozenset({2}))),
    }
    # outcome, HP, 实际扣减时间(可含最后行动债务), 强制损伤, 模块安全入库, 本次安装材料齐备
    route_expected={
        'first_visit_exact_zero':('safe-returned',1,200,0,True,True),
        'first_visit_exposure_preserved':('safe-returned',1,200,0,True,True),
        'prepared_terminal':('safe-returned',4,160,0,True,False),
        'pre_hub_bandage_then_defense':('safe-returned',1,190,0,True,True),
        'heal_in_fight_instead_of_charge':('safe-returned',1,200,0,True,True),
        'late_heal_extends_battle_and_dies_on_return':('dead',0,200,1,False,False),
        'scene_bandage_after_combo':('forced-returned',1,200,1,True,True),
        'also_take_ration_hp4_dies':('dead',0,200,2,False,False),
        'also_take_ration_hp6_returns':('forced-returned',1,200,2,True,True),
        'search_ration_last_revealed_not_picked':('forced-returned',1,210,2,True,True),
        'retreat_with_materials_no_module':('safe-returned',3,100,0,False,True),
        'existing_contusion_hp4_dies':('dead',0,208,1,False,False),
        'existing_contusion_hp5_returns':('forced-returned',1,208,1,True,True),
        'manual_first_visit_hp4_dies':('dead',0,210,2,False,False),
        'manual_prepared_hp7_returns':('safe-returned',4,180,0,True,False),
        'durability_three_first_visit':('safe-returned',1,200,0,True,True),
        'materials_taken_after_module':('safe-returned',1,200,0,True,True),
        'wound_after_basic_then_scene_bandage':('safe-returned',2,190,0,True,True),
    }
    routes={}
    rk=('outcome','hp','actual_scene_cost','forced_loss','task_module_safely_returned','current_visit_installation_materials')
    for name,(plan,actions,kwargs) in route_cases.items():
        r=run_route(route_actions(**plan),actions,**kwargs)
        assert tuple(r[k] for k in rk)==route_expected[name],(name,{k:r[k] for k in rk},route_expected[name])
        routes[name]=r
    assert routes['first_visit_exposure_preserved']['pending_exposure']==1
    assert routes['first_visit_exact_zero']['remaining']==0
    assert routes['first_visit_exact_zero']['pack_weight']==5
    assert 'ration' not in routes['search_ration_last_revealed_not_picked']['safely_returned_items']
    assert routes['search_ration_last_revealed_not_picked']['revealed_left']==['ration']
    assert routes['late_heal_extends_battle_and_dies_on_return']['carried_items'] # 临死携带，不安全提取
    assert routes['late_heal_extends_battle_and_dies_on_return']['safely_returned_items']==[]
    invalids={
        'cannot_retake_used_cabinet':lambda:run_route(route_actions(),COMBO,cabinet_used=True),
        'missing_interface_not_authorized_by_visit':lambda:run_route(route_actions(),COMBO,interface_known=False),
        'zero_injury_risk_cannot_be_forced_success':lambda:encounter(COMBO,hp=12,injury_hits=frozenset({2})),
        'light_attack_no_exposure':lambda:encounter(COMBO,hp=12,exposure_hits=frozenset({1})),
        'temporary_not_allowed_while_equipped_weapon_available':lambda:encounter(('temporary',)),
        'charge_cannot_repeat':lambda:encounter(('charged','charged'),hp=12),
    }
    rejected={}
    for name,fn in invalids.items():
        try:fn()
        except ValueError as e:rejected[name]=str(e)
        else:raise AssertionError(name)
    output=dict(
      method='独立纸面核算；不是仓库测试/正式命令回放，不证明游戏已实现',
      risk_method='指定风险分支，无随机采样，无胜率推断',
      count=dict(combat=len(combats),routes=len(routes),illegal_inputs=len(rejected),economy_paths=4),
      enemy_candidate=asdict(COMMUNICATION),combat=combats,routes=routes,
      rejected=rejected,economy=check_economy())
    folder=Path(__file__).parent
    (folder/'paper_results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=[output['method'],output['risk_method'],str(output['count'])]
    lines += [f"COMBAT {n}: "+str({k:r[k] for k in KEYS}) for n,r in combats.items()]
    lines += [f"ROUTE {n}: "+str({k:r[k] for k in rk}) for n,r in routes.items()]
    lines += [f"REJECT {n}: {e}" for n,e in rejected.items()]
    (folder/'check-output.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines))

if __name__=='__main__':main()
