# 跨日重访候选：独立纸面复核

状态：UNAPPROVED PROPOSAL / CONDITIONAL CALCULATION。

运行：`python revisit_checks.py`（Python 3.10+，仅标准库）。

- `reference_combat.py` 与 `prior_audit.py` 是上一轮核算包中的原脚本副本；后者原名 `audit_checks.py`。它们不是游戏源码。
- 新脚本从已有真实纸面前缀继续，显式采用“敌人伤害和下一意图持续、再接战50、已解除障碍/危险持续、不重复物资”的未确认假设。
- `revisit-results.json` 含前缀、条件性接续、完整CTB/路线记录和剩余状态。
- 不读取/改写玩家存档，不访问GitHub，不改正式DEC，没有种子胜率或全策略最优证明。
- 3条条件性终局接续、1条错误打法死亡反例、1个两段战斗例，不应合并宣传为5条完整世界验收通过。
- 摘要及来源哈希只说明本次计算输入；不证明生产物品身份、Schema、随机游标或严格恢复已经实现。
