"""Conditional paper calculation for a PROPOSED cross-day revisit contract.
Not repository code, not a save schema, not gameplay implementation authorization.
Reuses unmodified prior paper helpers. No RNG sampling, no network, no production saves.
Only listed candidate enemies and selected no-extra-injury branches are represented.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import hashlib
import json
from reference_combat import encounter, COMMUNICATION
from prior_audit import (Scene, stress_start, logistics, repair_logistics,
                        communication, run_spent_metal_prefix)

REENTRY_OFFSET = 50  # PROPOSAL, not an already-confirmed cross-day rule.
REENTRY_ACTIONS = ('defend', 'basic', 'basic', 'charged', 'basic')
OLD_FIRST_ACTIONS = ('basic', 'defend', 'charged', 'basic', 'basic')


def retreat_prefix():
    r = stress_start()
    logistics(r)
    repair_logistics(r)
    r.night('logistics-work')
    communication(r, retreat=True)
    r.repair_labor(coat=1, crowbar=2)
    r.night('logistics-work')
    assert (r.day, r.hp, r.satiety, r.weapon, r.coat, r.crowbar) == (4,5,4,6,4,3)
    assert r.snap()['counts']['ration'] == 1
    return r


def last_combat(run, place):
    for entry in reversed(run.log):
        if entry.get('event') == 'route-trace' and entry.get('place') == place:
            matches = [e['combat_trace'] for e in entry['trace'] if 'combat_trace' in e]
            if matches:
                return matches[-1]
    raise ValueError('No committed combat evidence in this paper prefix')


def has_completed_interaction(run, label):
    return any(step.get('action') == label
               for entry in run.log if entry.get('event') == 'route-trace'
               for step in entry['trace'])


def continuation_enemy(prior_result):
    """Derive next listed move from actually executed enemy moves, not visit date.
    This rotation is ONLY a small paper-model adapter; not production enemy identity.
    The full model would carry the same enemy identity and RNG continuation unchanged.
    """
    if prior_result['outcome'] != 'escaped' or prior_result['enemy_hp'] <= 0:
        raise ValueError('Only living escaped enemies can be resumed')
    moves = [e for e in prior_result['events'] if e.get('who') == 'enemy']
    next_index = len(moves) % len(COMMUNICATION.attacks)
    attacks = COMMUNICATION.attacks[next_index:] + COMMUNICATION.attacks[:next_index]
    return replace(COMMUNICATION, health=prior_result['enemy_hp'],
                   first_action=REENTRY_OFFSET, attacks=attacks), next_index


def finish_retreat(*, exposure=False, old_script=False):
    r = retreat_prefix()
    before = deepcopy(r.snap())
    prior = last_combat(r, 'communication')
    enemy, index = continuation_enemy(prior)
    assert prior['enemy_hp'] == 16 and index == 1
    assert has_completed_interaction(r, 'corridor-latch')
    assert 'communication-cabinet' in r.consumed_sources
    r.assumptions.append('PROPOSAL: keep enemy HP/next intent; reentry offset50; keep opened corridor; no offscreen regeneration; no source refill')
    s = Scene(r, 'communication')
    s.move('H')
    # No second cabinet or obstacle operation: the exact sources/results are already consumed/completed.
    s.move('P')
    cr = encounter(OLD_FIRST_ACTIONS if old_script else REENTRY_ACTIONS,
                   enemy=enemy,hp=r.hp,durability=r.weapon,coat=r.coat,
                   bandages=r.bandages,exposure_hits=frozenset({1}) if exposure else frozenset())
    def commit():
        r.hp=cr['hp'];r.weapon=cr['durability'];r.coat=cr['coat'];r.bandages=cr['bandages']
        r.wounds=deepcopy(cr['wounds']);r.bleeding=cr['bleeding'];r.contusion=cr['contusion']
        r.exposure+=cr['pending_exposure'];r.danger['communication']=cr['outcome']
    s.do('combat:proposed-persistent-reentry',cr['scene_time'],commit,combat=True)
    s.events.append({'combat_trace':cr})
    if not s.ended:
        s.move('R');s.interact('matching',10);s.extract('module',20)
        s.move('P');s.move('H');s.move('E')
    s.close()
    if r.hp > 0:
        r.finish()
    return dict(assumptions=r.assumptions,prefix_state=before,
                resumed_enemy_hp=enemy.health,resumed_intent=enemy.attacks[0].name,
                reentry_offset=REENTRY_OFFSET,combat=cr,route_time=s.elapsed,
                remaining_time=s.time,final=r.snap(),trace=r.log)


def finish_material_recovery():
    r = run_spent_metal_prefix()
    before = deepcopy(r.snap())
    assert (r.day,r.hp,r.satiety)==(4,3,4)
    assert r.danger.get('logistics')=='victory'
    assert 'logistics-shelf' not in r.consumed_sources
    r.assumptions.append('PROPOSAL: the defeated logistics enemy stays defeated; unredeemed shelf remains once; known observations reapply from entrance')
    s=Scene(r,'logistics')
    s.move('H');s.move('W');s.move('X')
    s.source('logistics-shelf',20,crowbar=True)
    s.move('W');s.move('H');s.move('E');s.close()
    r.finish(metal_source='logistics-shelf',electronic_source='communication-cabinet')
    return dict(assumptions=r.assumptions,prefix_state=before,route_time=s.elapsed,
                remaining_time=s.time,final=r.snap(),trace=r.log)


def split_enemy_breakthrough():
    first=encounter(('basic','defend','charged','escape'),hp=9)
    assert (first['outcome'],first['enemy_hp'],first['hp'],first['ctb'])==('escaped',6,6,440)
    resumed,index=continuation_enemy(first)
    # Starting equipment=3 is a separately explicit next-day input, not secretly repaired here.
    final=encounter(('charged',),enemy=resumed,hp=6,durability=3,coat=2)
    assert final['outcome']=='victory' and final['ctb']==0 and final['scene_time']==10
    return dict(assumption='PROPOSAL: same enemy HP6 remains; next exploration may use signature once anew; input weapon3 already sufficient, no repair implied',
                first_combat=first,reentry_next_index=index,next_combat=final,
                limit='Two combat segments only, not a complete two-day route, maintenance or night ledger')


def main():
    results={}
    for exposure in (False,True):
        case=finish_retreat(exposure=exposure)
        f=case['final'];c=case['combat']
        assert (f['day'],f['hp'],f['weapon'],f['coat'],f['crowbar'])==(4,2,0,2,3)
        assert f['terminal']=='success-no-overnight' and f['exposure']==int(exposure) and f['progress']==0
        assert (case['route_time'],case['remaining_time'],c['ctb'])==(140,60,460)
        assert f['bandages']==1 and f['counts']['ration']==1
        results[f'retreat-revisit-exposure-{int(exposure)}']=case
    wrong=finish_retreat(old_script=True)
    assert (wrong['final']['hp'],wrong['final']['terminal'])==(0,'scene-death')
    assert wrong['combat']['ctb']==370
    results['blindly-repeat-first-visit-script']=wrong
    material=finish_material_recovery()
    assert (material['final']['day'],material['final']['hp'],material['route_time'])==(4,3,80)
    assert material['final']['terminal']=='success-no-overnight'
    assert material['final']['crowbar']==2 and material['final']['counts']['metal']==0
    assert material['final']['counts']['electronic']==1  # unused spare, not installation double spend
    results['material-recovery-after-persistent-clearance']=material
    results['partial-damage-carry-two-combat-segments']=split_enemy_breakthrough()
    refused=0
    for result in (results['retreat-revisit-exposure-0']['combat'], {'outcome':'escaped','enemy_hp':0}):
        try: continuation_enemy(result)
        except ValueError:refused+=1
        else:raise AssertionError('cannot resume incapacitated enemy')
    out=Path(__file__).parent
    payload=dict(status='CONDITIONAL PAPER CHECK OF AN UNAPPROVED LIFECYCLE PROPOSAL',
                 complete_continuation_cases=3,lethal_counterexample_cases=1,
                 combat_segment_example_cases=1,refusal_assertions=refused,
                 limitations=['No gameplay source reviewed or modified','No production resolver, identity/restore/transaction verification',
                    'No seeded RNG or win-rate calculation','No automatic approval of enemy/loot/installation/revisit content',
                    'Old paper ledger uses simplified unit tokens, not production ItemInstance identities'],results=results)
    (out/'revisit-results.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['候选跨日重访：条件性纸面核算；不是实现、不是正式测试。',
           '3 complete conditional continuations (2 exposure branches + 1 material recovery), 1 lethal counterexample, 1 two-combat-segment example, 2 rejected reentry inputs.']
    for k,v in results.items():
        if 'final' in v:
            f=v['final'];lines.append(f'{k}: day={f["day"]} hp={f["hp"]} pending={f["exposure"]} route={v["route_time"]} terminal={f["terminal"]}')
        else:lines.append(k+': retained enemyHP6; new exploration signature kills atCTB0; battle minimum10')
    (out/'check-output.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines))

if __name__=='__main__':main()
