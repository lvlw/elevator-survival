"""Specified-paper-branch audit, not production gameplay code or complete strategy search.
Run: python audit_checks.py
Uses only reviewed previous paper CTB checker plus explicit route/maintenance/night ledgers.
No RNG sampling, runtime save files, repository access, undocumented enemy resets, or new rules.
Revisit assumptions, where used, are explicitly tagged sensitivity assumptions.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from copy import deepcopy
from math import ceil
from fractions import Fraction
from pathlib import Path
import json
from reference_combat import encounter, Enemy, Attack, LOGISTICS, COMMUNICATION

HOSPITAL=Enemy('正式医院护工对照',14,70,200,(
    Attack('抓挠',3,100,3,'laceration'),Attack('扑咬',7,140,4,'bite',3)))
HB=('basic','charged','basic')
HB_WOUND=('basic','charged','bandage','basic')
LD=('basic','defend','basic','basic','basic')
CC=('basic','defend','charged','basic','basic')
CLOW=('basic','defend','basic','charged','temporary')
WEIGHT={'metal':1,'cloth':1,'electronic':1,'battery':1,'ration':1,'bandage':1,
        'sample':4,'component':6,'module':2}
ITEMS={
 'hospital-hall':{'metal':1,'battery':1}, # specified valid random battery result, not a guarantee
 'logistics-front':{'ration':2,'bandage':1},
 'logistics-work':{'ration':3,'metal':1,'cloth':1},
 'logistics-shelf':{'metal':1,'electronic':1,'battery':1},
 'communication-cabinet':{'metal':1,'electronic':1,'battery':1},
 'communication-food':{'ration':1},
}
GRAPHS={
 'hospital':(('E','H'),('H','I'),('I','R')),
 'logistics':(('E','H'),('H','F'),('H','A'),('H','W'),('W','X')),
 'communication':(('E','H'),('H','D'),('H','A'),('H','P'),('P','R')),
}
# These are explicit content observations for the subset under test, not inherited map knowledge.
OBS={
 'hospital':{'E':(('E','H'),),'H':(('H','I'),),'I':(('I','R'),)},
 'logistics':{'E':(('E','H'),),'H':(('H','F'),('H','A'),('H','W')),'W':(('W','X'),)},
 'communication':{'E':(('E','H'),),'H':(('H','D'),('H','A'),('H','P')),'P':(('P','R'),)},
}

@dataclass
class PaperRun:
    hp:int=12
    satiety:int=6
    weapon:int=6
    coat:int=4
    crowbar:int=3
    bandages:int=1
    day:int=1
    labor:int=3
    progress:int=0
    exposure:int=0
    bleeding:bool=False
    contusion:bool=False
    wounds:list=field(default_factory=list)
    inventory:dict=field(default_factory=dict) # paper unit identity -> kind; never a real save schema
    consumed_sources:set=field(default_factory=set)
    intel:set=field(default_factory=set)
    danger:dict=field(default_factory=dict)
    used_today:bool=False
    terminal:str|None=None
    log:list=field(default_factory=list)
    assumptions:list=field(default_factory=list)

    def snap(self):
        return dict(day=self.day,hp=self.hp,satiety=self.satiety,weapon=self.weapon,coat=self.coat,
                    crowbar=self.crowbar,bandages=self.bandages,labor=self.labor,
                    progress=self.progress,exposure=self.exposure,bleeding=self.bleeding,
                    contusion=self.contusion,wounds=deepcopy(self.wounds),inventory=deepcopy(self.inventory),
                    counts={k:sum(x==k for x in self.inventory.values()) for k in WEIGHT},
                    terminal=self.terminal)
    def record(self,event,**more):self.log.append(dict(event=event,state=self.snap(),**more))
    def spend(self,source,kind):
        matches=[k for k,v in self.inventory.items() if v==kind and k.startswith(source+':')]
        if not matches:raise ValueError(f'missing {kind} from {source}')
        token=sorted(matches)[0]; del self.inventory[token];return token
    def repair_labor(self,**alloc):
        maximum={'weapon':6,'coat':4,'crowbar':3}
        if any(k not in maximum or v<0 or v+getattr(self,k)>maximum[k] for k,v in alloc.items()):
            raise ValueError('bad allocation')
        if sum(alloc.values())>self.labor:raise ValueError('insufficient daily labor')
        self.labor-=sum(alloc.values())
        for k,v in alloc.items():setattr(self,k,getattr(self,k)+v)
        self.record('labor',allocation=alloc)
    def repair_material(self,source,kind,**alloc):
        maxes={'weapon':6,'crowbar':3} if kind=='metal' else {'coat':4} if kind=='cloth' else {}
        cap=5 if kind=='metal' else 4
        if not maxes or sum(alloc.values())>cap or not any(alloc.values()):raise ValueError('invalid material')
        if any(k not in maxes or v<0 or v+getattr(self,k)>maxes[k] for k,v in alloc.items()):raise ValueError('bad allocation')
        unit=self.spend(source,kind)
        for k,v in alloc.items():setattr(self,k,getattr(self,k)+v)
        self.record('material-repair',unit=unit,allocation=alloc,waste=cap-sum(alloc.values()))
    def bandage_hub(self,source=None):
        if self.hp==12 and not self.bleeding and all(w['treated'] for w in self.wounds):raise ValueError('bandage unavailable')
        if source:unit=self.spend(source,'bandage')
        else:
            if not self.bandages:raise ValueError('no bandage')
            self.bandages-=1;unit='initial-quick-bandage'
        self.hp=min(12,self.hp+1);self.bleeding=False
        for w in self.wounds:
            if not w['treated']:w['treated']=True;break
        self.record('explicit-hub-bandage',unit=unit)
    def night(self,food_source=None):
        if self.terminal or not self.used_today or self.day>=7:raise ValueError('ordinary next day unavailable')
        if food_source:
            if self.satiety>=6:raise ValueError('cannot eat while full')
            token=self.spend(food_source,'ration');self.satiety=min(6,self.satiety+2)
            self.record('eat',unit=token)
        if self.bleeding:
            self.hp=max(0,self.hp-2)
            if self.hp==0:
                self.terminal='bleeding-death';self.record('night-terminal');return
        p=self.progress
        base=0 if p==0 else 5 if p<30 else 10 if p<60 else 15 if p<90 else 20
        self.progress+=base+20*self.exposure;self.exposure=0
        if self.progress>=120:
            self.terminal='infection-terminal';self.record('night-terminal');return
        self.satiety=max(0,self.satiety-2)
        if self.satiety<=1:
            self.hp=max(0,self.hp-1);recovery=0
        else:
            recovery=2 if self.satiety>=4 else 1
            injury_penalty=min(2,int(self.contusion)+sum(not w['treated'] for w in self.wounds))
            recovery=max(0,recovery-injury_penalty)
            if self.progress>=60:recovery=0
            elif self.progress>=30:recovery=max(0,recovery-1)
            if self.bleeding:recovery=0
        if self.hp==0:
            self.terminal='deprivation-death';self.record('night-terminal');return
        self.hp=min(12,self.hp+recovery)
        self.contusion=False;self.wounds=[w for w in self.wounds if not w['treated']]
        self.day+=1;self.labor=3;self.used_today=False
        self.record('next-day',actual_recovery=recovery)
    def finish(self,metal_source='communication-cabinet',electronic_source='communication-cabinet'):
        if self.terminal or not self.used_today or self.hp<=0 or self.progress>=120:raise ValueError('success unavailable')
        if not all(k in self.inventory.values() for k in ('sample','component','module')):raise ValueError('missing tasks')
        # validate both material units before spending either
        for source,kind in ((metal_source,'metal'),(electronic_source,'electronic')):
            if not any(v==kind and k.startswith(source+':') for k,v in self.inventory.items()):raise ValueError('missing install material')
        self.spend(metal_source,'metal');self.spend(electronic_source,'electronic')
        self.terminal='success-no-overnight';self.record('success')

class Scene:
    def __init__(self,r:PaperRun,place:str):
        if r.used_today or r.terminal:raise ValueError('second scene same day / terminal')
        r.used_today=True;self.r=r;self.place=place;self.pos='E';self.time=200
        self.known={tuple(sorted(e)) for e in OBS[place]['E']};self.carried={};self.revealed={}
        self.ended=False;self.events=[];self.elapsed=0;self.forced_loss=0
    def move_cost(self):
        w=sum(WEIGHT[k] for k in self.carried.values())
        if w>=29:raise ValueError('cannot carry')
        return ceil(10*(Fraction(1) if w<=16 else Fraction(11,10) if w<=24 else Fraction(5,4))*(Fraction(11,10) if self.r.contusion else 1))
    def back(self):
        queue=[(self.pos,0)];seen=set()
        while queue:
            n,d=queue.pop(0)
            if n=='E':return d
            if n in seen:continue
            seen.add(n)
            for a,b in self.known:
                nxt=b if n==a else a if n==b else None
                if nxt is not None and nxt not in seen:queue.append((nxt,d+self.move_cost()))
        raise ValueError('unknown return')
    def do(self,label,cost,effect=None,combat=False):
        if self.ended: return False
        if self.time<=0:raise ValueError('action at zero')
        before=self.time
        if effect:effect()
        self.time=max(0,before-cost);debt=max(0,cost-before);self.elapsed+=cost
        if self.r.hp>0 and cost>0 and self.r.bleeding and not combat:self.r.hp-=1
        if self.r.hp<=0:
            self.r.terminal='scene-death';self.ended=True
        elif self.pos=='E' and label.startswith('move') and debt==0:self.returned('safe',0,0)
        elif self.time==0:
            distance=self.back();loss=min(4,ceil((debt+distance)/20))+(1 if self.r.bleeding and debt+distance else 0)
            self.r.hp=max(0,self.r.hp-loss);self.forced_loss=loss
            if self.r.hp==0:self.r.terminal='forced-return-death';self.ended=True
            else:self.returned('forced',debt,distance)
        self.events.append(dict(action=label,cost=cost,time=self.time,node=self.pos,hp=self.r.hp,
                                weapon=self.r.weapon,coat=self.r.coat,crowbar=self.r.crowbar,debt=debt,
                                packed=list(self.carried),pending_exposure=self.r.exposure))
        return True
    def returned(self,kind,debt,distance):
        for unit,item in self.carried.items():
            if unit in self.r.inventory:raise ValueError('duplicate unit')
            self.r.inventory[unit]=item
        self.ended=True;self.pos='E'
        self.r.record('scene-return',place=self.place,kind=kind,debt=debt,distance=distance,loss=self.forced_loss)
    def move(self,target):
        edge=tuple(sorted((self.pos,target)))
        if not self.ended and edge not in self.known:raise ValueError(f'unknown move {edge}')
        def f():
            self.pos=target;self.known.update(tuple(sorted(e)) for e in OBS[self.place].get(target,()))
        self.do('move:'+target,self.move_cost(),f)
    def interact(self,name,cost,crowbar=False,info=None):
        def f():
            if crowbar:
                if self.r.crowbar<1:raise ValueError('crowbar unavailable')
                self.r.crowbar-=1
            if info:self.r.intel.add(info)
        self.do(name,cost,f)
    def source(self,source,cost,crowbar=False):
        def f():
            if source in self.r.consumed_sources:raise ValueError('source already consumed')
            if crowbar:
                if self.r.crowbar<1:raise ValueError('crowbar unavailable')
                self.r.crowbar-=1
            self.r.consumed_sources.add(source)
            for kind,n in ITEMS[source].items():
                for i in range(n):self.revealed[f'{source}:{kind}:{i}']=kind
        self.do('reveal:'+source,cost,f)
        if not self.ended:
            # each unit is explicitly requested by this fixed test recipe; not game auto-loot
            for unit in list(self.revealed):
                self.do('pickup:'+unit,0,lambda unit=unit:self.carried.update({unit:self.revealed.pop(unit)}))
    def extract(self,kind,cost,sample_risk=False):
        def f():
            unit='task:'+kind+':0'
            if unit in self.r.inventory or unit in self.carried:raise ValueError('duplicate task')
            self.carried[unit]=kind
            if kind=='sample':
                if self.r.coat>0:self.r.coat-=1
                if sample_risk:self.r.exposure+=1
        self.do('extract:'+kind,cost,f)
    def fight(self,enemy,actions,injury_hits=frozenset(),exposure_hits=frozenset()):
        state=self.r.danger.get(self.place)
        if state is not None:raise ValueError('undefined cross-day encounter continuation; do not reset implicitly')
        cr=encounter(actions,enemy=enemy,hp=self.r.hp,durability=self.r.weapon,coat=self.r.coat,
                     bandages=self.r.bandages,injury_hits=injury_hits,exposure_hits=exposure_hits,
                     initial_bleeding=self.r.bleeding,initial_contusion=self.r.contusion,
                     initial_untreated_wounds=sum(not w['treated'] for w in self.r.wounds))
        def f():
            self.r.hp=cr['hp'];self.r.weapon=cr['durability'];self.r.coat=cr['coat'];self.r.bandages=cr['bandages']
            self.r.bleeding=cr['bleeding'];self.r.contusion=cr['contusion'];self.r.wounds=deepcopy(cr['wounds'])
            self.r.exposure+=cr['pending_exposure']
            self.r.danger[self.place]=cr['outcome']
            if cr['outcome']=='escaped':self.pos='H'
            elif cr['outcome'] not in ('victory','dead'):raise ValueError('incomplete combat script')
        self.do('combat:'+enemy.name,cr['scene_time'],f,combat=True)
        self.events.append({'combat_trace':cr})
    def close(self):
        if not self.ended:raise ValueError('recipe unfinished')
        self.r.log.append({'event':'route-trace','place':self.place,'charged_time':self.elapsed,'forced_loss':self.forced_loss,
                           'safely_carried':list(self.carried) if self.r.hp>0 else [],'trace':self.events,'state':self.r.snap()})

def hospital(r,direct=False,wound=False,sample_risk=False):
    s=Scene(r,'hospital');s.move('H');s.source('hospital-hall',30);s.interact('fire-door',20,crowbar=True)
    s.move('I');s.fight(HOSPITAL,HB_WOUND if wound else HB,injury_hits=frozenset({1}) if wound else frozenset())
    s.move('R');s.extract('sample',10 if direct else 30,sample_risk=sample_risk)
    s.move('I');s.move('H');s.move('E');s.close()

def logistics(r,loot=True,retreat=False):
    s=Scene(r,'logistics');s.move('H')
    if 'logistics-record' not in r.intel:
        s.move('A');s.interact('local-record',40,info='logistics-record');s.move('H')
    s.move('W');s.fight(LOGISTICS,('escape',) if retreat else LD)
    if retreat:s.move('E');s.close();return
    s.interact('interface',10,info='interface');s.interact('transport-latch',20,crowbar=True)
    if loot:s.source('logistics-work',30)
    s.extract('component',20);s.move('H');s.move('E');s.close()

def local_preparation(r):
    s=Scene(r,'logistics');s.move('H');s.move('F');s.interact('front-latch',20,crowbar=True)
    s.source('logistics-front',30);s.move('H');s.move('A');s.interact('local-record',40,info='logistics-record')
    s.move('H');s.move('E');s.close()

def survey(r):
    s=Scene(r,'communication');s.move('H');s.move('A');s.interact('dispatch-record',30,info='logistics-record')
    s.move('H');s.move('D');s.source('communication-cabinet',20,crowbar=True);s.source('communication-food',30)
    s.move('H');s.move('E');s.close()

def communication(r,retreat=False,exposure=False):
    if not retreat and 'interface' not in r.intel:raise ValueError('missing interface')
    s=Scene(r,'communication');s.move('H')
    if 'communication-cabinet' not in r.consumed_sources:
        s.move('D');s.source('communication-cabinet',20,crowbar=True);s.move('H')
    s.interact('corridor-latch',20,crowbar=True);s.move('P')
    seq=('escape',) if retreat else CC
    s.fight(COMMUNICATION,seq,exposure_hits=frozenset({2}) if exposure else frozenset())
    if retreat:s.move('E');s.close();return
    s.move('R');s.interact('matching',10);s.extract('module',20);s.move('P');s.move('H');s.move('E');s.close()

def repair_hospital(r):r.repair_material('hospital-hall','metal',weapon=5);r.repair_labor(coat=2,crowbar=1)
def repair_logistics(r):r.repair_material('logistics-work','metal',weapon=4,crowbar=1);r.repair_labor(coat=1)
def stress_start():
    r=PaperRun(hp=6,satiety=4,day=2);r.inventory['task:sample:0']='sample'
    r.consumed_sources.add('hospital-hall');r.danger['hospital']='victory'
    r.assumptions.append('specified previously studied Day2 HP6 state, not a Day1 simulation')
    return r

def run_fair(order,wound=False,exposure=False,direct=False):
    r=PaperRun();r.assumptions+=['hospital hall random battery branch; no randomized generator executed',
                                'specified hospital injury and communication exposure branches, not a common RNG seed']
    for place in order:
        if place=='H':hospital(r,direct=direct and r.day==3,wound=wound,sample_risk=direct and r.day==3)
        elif place=='L':logistics(r)
        else:communication(r,exposure=exposure)
        if r.hp<=0:break
        if r.day==3:r.finish();break
        if place=='H':repair_hospital(r)
        elif place=='L':repair_logistics(r)
        else:
            # Communication before hospital: cannot presume full repair with installation metal.
            r.repair_labor(weapon=3)
            r.repair_material('logistics-work','cloth',coat=2) # two points wasted, not banked
        food='logistics-work' if r.day==2 else None
        r.night(food)
        if place=='C':r.repair_labor(weapon=2,crowbar=1) # leaves weapon5/crowbar2 sufficient for H
    return r

def run_survey_stress():
    r=stress_start();survey(r);r.repair_labor(crowbar=1);r.night('communication-food')
    logistics(r);repair_logistics(r);r.night('logistics-work');communication(r);r.finish();return r

def run_local_stress():
    r=stress_start();local_preparation(r);r.bandage_hub('logistics-front');r.repair_labor(crowbar=1);r.night('logistics-front')
    logistics(r);repair_logistics(r);r.night('logistics-front');communication(r);r.finish();return r

def run_compact_stress():
    r=stress_start();logistics(r);repair_logistics(r);r.night('logistics-work');communication(r);r.finish();return r

def run_healthy_survey():
    r=PaperRun();hospital(r);repair_hospital(r);r.night()
    survey(r);r.repair_labor(crowbar=1);r.night('communication-food')
    logistics(r);repair_logistics(r);r.night('logistics-work');communication(r);r.finish();return r

def run_late_hospital_partial_repair():
    r=PaperRun();logistics(r);repair_logistics(r);r.night()
    communication(r,exposure=True);r.repair_labor(weapon=3);r.night('logistics-work')
    r.repair_labor(weapon=2) # weapon5, coat2 and crowbar1 suffice; no full-repair assumption
    hospital(r);r.finish();return r

def run_compact_use_bandage():
    r=stress_start();logistics(r);repair_logistics(r);r.night('logistics-work')
    r.bandage_hub();communication(r);r.finish();return r

def run_retreat_prefix():
    r=stress_start();logistics(r);repair_logistics(r);r.night('logistics-work')
    communication(r,retreat=True);r.repair_labor(coat=1,crowbar=2);r.night('logistics-work')
    before=deepcopy(r)
    try:communication(r)
    except ValueError as e:
        before.record('blocked-at-undefined-revisit',reason=str(e))
        return before
    raise AssertionError('should not silently reset enemy')

def run_spent_metal_prefix():
    r=stress_start();logistics(r);repair_logistics(r);r.night('logistics-work');communication(r)
    # Legal but unnecessary repair after collecting final module, using actual final metal.
    r.repair_material('communication-cabinet','metal',weapon=5)
    r.repair_labor(weapon=1,crowbar=2)
    r.repair_material('logistics-work','cloth',coat=2)
    try:r.finish()
    except ValueError as e:r.record('cannot-install',reason=str(e))
    else:raise AssertionError('spent metal wrongly reused')
    r.night('logistics-work')
    r.record('material-recovery-blocked-by-undefined-danger-persistence')
    return r

def sensitivity_shelf_clear(prefix):
    r=deepcopy(prefix);r.assumptions.append('SENSITIVITY ONLY: defeated logistics danger remains cleared across dates')
    s=Scene(r,'logistics');s.move('H');s.move('W');s.move('X');s.source('logistics-shelf',20,crowbar=True)
    s.move('W');s.move('H');s.move('E');s.close()
    r.finish('logistics-shelf');return r

def short_noncombat_day(r):
    # Legal small visit and return, not a new rest/skip command, no loot.
    s=Scene(r,'logistics');s.move('H');s.move('E');s.close()

def main():
    results={};checks=[]
    for order in ('HLC','LHC','LCH'):
        for wound in (False,True):
            for exposure in (False,True):
                key=f'fair_{order}_hospital-wound-{int(wound)}_communication-exposure-{int(exposure)}'
                r=run_fair(order,wound,exposure)
                assert r.terminal=='success-no-overnight' and r.day==3 and r.hp==7,(key,r.snap())
                assert r.satiety==4 and r.snap()['counts']['ration']==2
                results[key]=r
    # Direct final sample is an immediate-exit counterexample, including a specified exposure hit.
    for direct in (False,True):
        r=run_fair('LCH',wound=False,exposure=True,direct=direct)
        assert r.hp==7 and r.progress==20 and r.exposure==int(direct)
        results[f'final-hospital-direct-{int(direct)}']=r
    for name,fn,hp,day in [('survey-stress',run_survey_stress,4,4),('local-investigation-stress',run_local_stress,5,4),('compact-stress',run_compact_stress,1,3)]:
        r=fn();assert (r.hp,r.day,r.terminal)==(hp,day,'success-no-overnight'),(name,r.snap());results[name]=r
    for name,fn,hp,day in [('healthy-survey',run_healthy_survey,8,4),('late-hospital-partial-repair',run_late_hospital_partial_repair,7,3),('compact-use-bandage',run_compact_use_bandage,2,3)]:
        r=fn();assert (r.hp,r.day,r.terminal)==(hp,day,'success-no-overnight');results[name]=r
    p=run_retreat_prefix();assert (p.day,p.hp,p.satiety)==(4,5,4);results['retreat-prefix-unresolved-revisit']=p
    p=run_spent_metal_prefix();assert (p.day,p.hp,p.satiety)==(4,3,4);results['spent-install-metal-prefix']=p
    q=sensitivity_shelf_clear(p);assert (q.day,q.hp)==(4,3);results['spent-metal-cleared-danger-SENSITIVITY']=q
    # Demonstrate repeat short visits can turn existing food and dates into recovery, not new food.
    r=stress_start();logistics(r);repair_logistics(r);r.night('logistics-work')
    r.assumptions.append('two rations really obtained from Day2 logistics; two later short visits generate no new loot')
    short_noncombat_day(r);r.night('logistics-work');short_noncombat_day(r);r.night('logistics-work')
    assert (r.day,r.hp,r.satiety)==(5,8,4)
    communication(r);r.finish()
    assert r.hp==5 and r.snap()['counts']['ration']==0
    results['two-short-visits-with-owned-food']=r
    for name,r in results.items():
        ids=list(r.inventory);assert len(ids)==len(set(ids))
        for entry in r.log:
            if 'state' in entry:
                s=entry['state'];assert 0<=s['labor']<=3 and 0<=s['weapon']<=6 and 0<=s['coat']<=4 and 0<=s['crowbar']<=3
        checks.append(name)
    output={'method':'specified branch paper audit; not production resolver, no seeded RNG, no policy optimization',
            'reviewed_case_count':len(results),'case_names':checks,
            'scope_limitations':['new scene content remains candidate','recipe verifier is not full action legality/schema/identity verifier',
                'no automatic cross-day enemy continuation','default hall battery only one valid branch; used for no critical requirement',
                'sample final direct analysis excludes undefined scoring/ending rewards','not a proof of optimality or win probability'],
            'results':{k:{'assumptions':r.assumptions,'final':r.snap(),'trace':r.log} for k,r in results.items()}}
    out=Path(__file__).parent
    (out/'audit_results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
    summary=['独立纸面整局反例核算，不是仓库测试；指定风险结果，不是种子配对或胜率。',f'cases={len(results)}']
    for name,r in results.items():
        s=r.snap();summary.append(f'{name}: day={r.day} hp={r.hp} satiety={r.satiety} infection={r.progress} pending={r.exposure} weapon={r.weapon} coat={r.coat} crowbar={r.crowbar} labor={r.labor} bandage={r.bandages} food={s["counts"]["ration"]} terminal={r.terminal}')
    (out/'check-output.txt').write_text('\n'.join(summary)+'\n',encoding='utf-8');print('\n'.join(summary))
if __name__=='__main__':main()
