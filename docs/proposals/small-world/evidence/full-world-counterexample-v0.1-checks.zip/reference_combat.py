"""通信终段候选的独立纸面核算，不是生产 resolver 或完整游戏模拟器。
所有风险分支由用例显式指定；不抽随机数、不访问网络/系统时间/存档。
本模块覆盖金属管、临时攻击、防御、绷带、初次逃跑及候选敌人两招。
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from math import ceil

@dataclass(frozen=True)
class Attack:
    name: str
    damage: int
    cooldown: int
    injury_tier: int
    injury_kind: str
    exposure_tier: int = 0

@dataclass(frozen=True)
class Enemy:
    name: str
    health: int
    first_action: int
    delay_from_charge: int
    attacks: tuple[Attack, ...]

COMMUNICATION = Enemy('感染检修员（候选）',16,60,140,(
    Attack('工具挥击',2,110,2,'contusion',0),
    Attack('逼近撕咬',5,180,3,'bite',2),
))
LOGISTICS = Enemy('感染搬运工（已有候选）',16,150,140,(
    Attack('重砸',6,240,3,'contusion'),
    Attack('回钩横扫',3,100,3,'laceration'),
))


def encounter(actions: tuple[str, ...], *, enemy: Enemy = COMMUNICATION,
              hp: int = 4, durability: int = 6, coat: int = 4,
              bandages: int = 1, injury_hits: frozenset[int] = frozenset(),
              exposure_hits: frozenset[int] = frozenset(),
              initial_bleeding: bool = False, initial_contusion: bool = False,
              initial_untreated_wounds: int = 0, escape_base: int = 80) -> dict:
    if not (0 < hp <= 12 and 0 <= durability <= 6 and 0 <= coat <= 4):
        raise ValueError('Invalid starting health/equipment')
    if bandages < 0 or initial_untreated_wounds < 0 or escape_base not in (80,110):
        raise ValueError('Invalid medical/escape input')
    initial_dur, initial_coat = durability, coat
    enemy_hp, enemy_at, enemy_index = enemy.health, enemy.first_action, 0
    player_at, now, defend = 0, 0, False
    charged_used = False
    bleeding, contusion = initial_bleeding, initial_contusion
    wounds = [{'kind':'initial-wound','treated':False} for _ in range(initial_untreated_wounds)]
    direct_loss = bleed_loss = restored = pending_exposure = 0
    attack_count = 0
    events = []

    def record(who: str, action: str, **extra) -> None:
        events.append(dict(ctb=now, who=who, action=action, hp=hp,
                           enemy_hp=enemy_hp, durability=durability, coat=coat,
                           bleeding=bleeding, contusion=contusion,
                           pending_exposure=pending_exposure, **extra))

    def result(outcome: str) -> dict:
        return dict(outcome=outcome, ctb=now, scene_time=max(10,ceil(now/100)*10),
                    hp=hp, enemy_hp=enemy_hp, durability=durability, coat=coat,
                    bandages=bandages, wounds=wounds, bleeding=bleeding,
                    contusion=contusion, pending_exposure=pending_exposure,
                    direct_loss=direct_loss, bleed_loss=bleed_loss, healing=restored,
                    durability_spent=initial_dur-durability,
                    coat_spent=initial_coat-coat, charged_used=charged_used,
                    events=events)

    def enemy_action() -> None:
        nonlocal hp, coat, defend, bleeding, contusion, enemy_at, enemy_index
        nonlocal direct_loss, attack_count, pending_exposure
        attack=enemy.attacks[enemy_index]
        protected=coat>0
        loss=max(0,attack.damage-(1 if protected else 0))
        injury_tier=max(0,attack.injury_tier-(2 if protected else 0))
        exposure_tier=max(0,attack.exposure_tier-(1 if protected else 0))
        was_defended=defend
        if defend:
            loss=ceil(loss/2)
            injury_tier=max(0,injury_tier-1)
        if protected: coat-=1
        defend=False
        requested_loss=loss
        loss=min(hp,loss)
        hp-=loss
        direct_loss+=loss
        attack_count+=1
        injury_applied=exposure_applied=False
        if hp>0:
            if attack_count in injury_hits:
                if injury_tier==0: raise ValueError('Requested impossible injury at zero risk')
                injury_applied=True
                if attack.injury_kind=='contusion': contusion=True
                else:
                    wounds.append({'kind':attack.injury_kind,'treated':False})
                    bleeding=True
            if attack_count in exposure_hits:
                if exposure_tier==0: raise ValueError('Requested impossible exposure at zero risk')
                exposure_applied=True
                pending_exposure+=1
        record('enemy',attack.name,requested_loss=requested_loss,actual_loss=loss,
               defended=was_defended,injury_tier=injury_tier,exposure_tier=exposure_tier,
               injury_applied=injury_applied,exposure_applied=exposure_applied,
               attack_ordinal=attack_count)
        if hp>0:
            enemy_at=now+attack.cooldown
            enemy_index=(enemy_index+1)%len(enemy.attacks)

    for action in actions:
        while enemy_at<player_at:
            now=enemy_at
            enemy_action()
            if hp==0: return result('dead')
        now=player_at
        defend=False  # 先前防御在本次玩家行动机会到期；同点玩家先于敌人。
        if action=='escape':
            untreated=sum(not w['treated'] for w in wounds)
            complete=now+escape_base+min(untreated*10,20)
            record('player','escape-start',completes_at=complete)
            while enemy_at<complete:
                now=enemy_at
                enemy_action()
                if hp==0: return result('dead')
            now=complete
            if bleeding:
                hp-=1
                bleed_loss+=1
            record('player','escape-complete')
            return result('dead' if hp==0 else 'escaped')
        if action=='basic':
            if durability<1: raise ValueError('basic unavailable')
            enemy_hp=max(0,enemy_hp-4)
            durability-=1
            cost=100
        elif action=='charged':
            if durability<1 or charged_used: raise ValueError('charged unavailable')
            enemy_hp=max(0,enemy_hp-6)
            durability=max(0,durability-3)
            charged_used=True
            enemy_at+=enemy.delay_from_charge
            cost=180
        elif action=='temporary':
            if durability!=0: raise ValueError('temporary unavailable')
            enemy_hp=max(0,enemy_hp-2)
            cost=140
        elif action=='defend':
            defend=True
            cost=80
        elif action=='bandage':
            if bandages<1 or (hp==12 and not bleeding and all(w['treated'] for w in wounds)):
                raise ValueError('bandage unavailable')
            bandages-=1
            gain=min(1,12-hp)
            hp+=gain
            restored+=gain
            bleeding=False
            # 本脚本用例明确选择首个尚未处理伤口，不表示生产自动选择。
            for wound in wounds:
                if not wound['treated']:
                    wound['treated']=True
                    break
            cost=80
        else: raise ValueError(f'Unknown action: {action}')
        if bleeding:
            hp-=1
            bleed_loss+=1
        record('player',action)
        if hp==0: return result('dead')
        if enemy_hp==0: return result('victory')
        player_at=now+cost
    return result('script-ended')
