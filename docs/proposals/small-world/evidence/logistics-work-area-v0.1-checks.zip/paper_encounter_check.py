"""独立纸面核算器：不是《电梯求生》正式 resolver / 测试或实现。
正式语义取自 DEC-031/035/036/037，敌人数值来自本轮候选。
不访问网络/时间/随机源，不写游戏状态；风险结果由用例显式给定。
仅核查本文的单次遭遇与无流血路线；不实现跨日敌人恢复。
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from math import ceil
import json
from pathlib import Path

@dataclass(frozen=True)
class Attack:
    name: str
    damage: int
    cooldown: int
    injury_tier: int
    injury: str

# 本轮候选：首次150；重砸后240、横扫后100；没有钝击控制弱点。
ATTACKS = (Attack('重砸', 6, 240, 3, 'contusion'),
           Attack('回钩横扫', 3, 100, 3, 'laceration'))


def encounter(actions: tuple[str, ...], *, hp: int=6, durability: int=6,
              coat: int=4, bandages: int=1, first_enemy_at: int=150,
              injury_successes: frozenset[int]=frozenset()) -> dict:
    if not (0 < hp <= 12 and 0 <= durability <= 6 and 0 <= coat <= 4):
        raise ValueError('Invalid initial state')
    initial_hp, initial_dur, initial_coat = hp, durability, coat
    enemy_hp, enemy_at, enemy_index = 16, first_enemy_at, 0
    player_at, now, defend = 0, 0, False
    charged_used, bleeding, contusion, wounds = False, False, False, 0
    direct_loss = bleed_loss = restored = 0
    attack_count = 0
    events: list[dict] = []

    def event(who: str, action: str, **extra) -> None:
        events.append(dict(ctb=now, who=who, action=action, hp=hp,
                           enemy_hp=enemy_hp, durability=durability,
                           coat=coat, bleeding=bleeding, contusion=contusion,
                           **extra))

    def result(outcome: str) -> dict:
        return dict(outcome=outcome, ctb=now, scene_time=max(10, ceil(now/100)*10),
                    hp=hp, enemy_hp=enemy_hp, durability=durability, coat=coat,
                    bandages=bandages, wounds=wounds, bleeding=bleeding,
                    contusion=contusion, direct_loss=direct_loss,
                    bleed_loss=bleed_loss, healing=restored,
                    actual_durability_spent=initial_dur-durability,
                    coat_spent=initial_coat-coat, events=events)

    def enemy_action() -> None:
        nonlocal hp, coat, defend, bleeding, contusion, wounds, enemy_at
        nonlocal enemy_index, direct_loss, attack_count
        attack = ATTACKS[enemy_index]
        effective_coat = coat > 0
        loss = max(0, attack.damage-(1 if effective_coat else 0))
        tier = max(0, attack.injury_tier-(2 if effective_coat else 0))
        if defend:
            loss = ceil(loss/2)
            tier = max(0, tier-1)
        if effective_coat:
            coat -= 1
        defend = False
        actual_loss = min(hp, loss)
        hp -= actual_loss
        direct_loss += actual_loss
        attack_count += 1
        # 直接伤害致死，不再执行风险；零风险没有成功分支。
        injury = hp > 0 and tier > 0 and attack_count in injury_successes
        if injury:
            if attack.injury == 'contusion':
                contusion = True
            else:
                wounds += 1
                bleeding = True
        event('enemy', attack.name, damage=actual_loss, injury_tier=tier,
              injury_applied=injury)
        if hp > 0:
            enemy_at = now + attack.cooldown
            enemy_index = (enemy_index+1) % len(ATTACKS)

    for action in actions:
        while enemy_at < player_at:
            now = enemy_at
            enemy_action()
            if hp == 0:
                return result('dead')
        now = player_at
        defend = False  # 先前防御至本次玩家行动机会到期。
        if action == 'escape':
            completion = now + 80 + min(wounds*10, 20)
            event('player', 'escape-start', completes_at=completion)
            while enemy_at < completion:
                now = enemy_at
                enemy_action()
                if hp == 0:
                    return result('dead')
            now = completion  # 完成事件先于同点敌人。
            if bleeding:
                hp -= 1
                bleed_loss += 1
            event('player', 'escape-complete')
            return result('dead' if hp == 0 else 'escaped')
        if action == 'basic':
            if durability < 1: raise ValueError('basic unavailable')
            enemy_hp = max(0, enemy_hp-4)
            durability -= 1
            cost = 100
        elif action == 'charged':
            if durability < 1 or charged_used: raise ValueError('charged unavailable')
            enemy_hp = max(0, enemy_hp-6)
            durability = max(0, durability-3)
            charged_used = True
            enemy_at += 140
            cost = 180
        elif action == 'temporary':
            if durability != 0: raise ValueError('temporary unavailable')
            enemy_hp = max(0, enemy_hp-2)
            cost = 140
        elif action == 'defend':
            defend = True
            cost = 80
        elif action == 'bandage':
            if bandages < 1 or (hp == 12 and not bleeding and wounds == 0):
                raise ValueError('bandage unavailable')
            bandages -= 1
            actual = min(1, 12-hp)
            hp += actual
            restored += actual
            bleeding = False
            wounds = max(0, wounds-1)
            cost = 80
        else:
            raise ValueError(f'Unknown action {action}')
        if bleeding:
            hp -= 1
            bleed_loss += 1
        event('player', action)
        if hp == 0: return result('dead')
        if enemy_hp == 0: return result('victory')
        player_at = now+cost
    return result('script-ended')


CASES = {
    'defend_then_finish': dict(actions=('basic','defend','basic','basic','basic')),
    'four_basics_no_injury': dict(actions=('basic',)*4),
    'four_basics_contusion': dict(actions=('basic',)*4, injury_successes=frozenset({1})),
    'hospital_style_charge': dict(actions=('basic','charged','basic','basic')),
    'bandage_during_fight_no_injury': dict(actions=('basic','defend','basic','bandage','basic','basic')),
    'bandage_during_fight_laceration': dict(actions=('basic','defend','basic','bandage','basic','basic'), injury_successes=frozenset({2})),
    'immediate_escape': dict(actions=('escape',)),
    'last_durability_three': dict(actions=('basic','basic','charged','temporary'), durability=3),
    'low_hp_three_defend_death': dict(actions=('basic','defend','basic','basic','basic'), hp=3),
    'health_four_defend': dict(actions=('basic','defend','basic','basic','basic'), hp=4),
}
EXPECTED = {
    'defend_then_finish': ('victory',380,40,3,2,3,False,False),
    'four_basics_no_injury': ('victory',300,30,1,2,3,False,False),
    'four_basics_contusion': ('victory',300,30,1,2,3,False,True),
    'hospital_style_charge': ('victory',380,40,1,0,3,False,False),
    'bandage_during_fight_no_injury': ('victory',460,50,2,2,2,False,False),
    'bandage_during_fight_laceration': ('victory',460,50,1,2,2,True,False),
    'immediate_escape': ('escaped',80,10,6,6,4,False,False),
    'last_durability_three': ('victory',380,40,1,0,3,False,False),
    'low_hp_three_defend_death': ('dead',150,20,0,5,3,False,False),
    'health_four_defend': ('victory',380,40,1,2,3,False,False),
}


def full_loot_route(*, ctb_cost: int, hp_after_combat: int,
                    contusion: bool=False) -> dict:
    """现场核查后取全物资；仅无流血分支。搜索在任务提取前，防止0时拾取。"""
    remaining = 200
    records = []
    # E->H->R (20), records40, R->H->W(20); prior movement uninjured.
    for name, time in [('入口到大厅',10),('大厅到记录室',10),('现场核查',40),
                       ('记录室到大厅',10),('大厅到作业区',10),('战斗',ctb_cost),
                       ('核验接口',10),('解卡件',20),('搜索补给并在正时间时拾取',30),
                       ('提取组件',20)]:
        if remaining <= 0: raise ValueError('Action cannot start at zero')
        debt = max(0, time-remaining)
        remaining = max(0, remaining-time)
        records.append(dict(action=name, cost=time, remaining=remaining))
        if remaining == 0:
            return_time = 22 if contusion else 20
            loss = min(4, ceil((debt+return_time)/20))
            return dict(hp=max(0,hp_after_combat-loss), forced_loss=loss,
                        cause=name, debt=debt, return_time=return_time, records=records)
    step = 11 if contusion else 10
    for name, back in [('作业区到大厅',step), ('大厅到入口',0)]:
        debt = max(0, step-remaining)
        remaining = max(0, remaining-step)
        records.append(dict(action=name, cost=step, remaining=remaining))
        if remaining == 0:
            loss = min(4, ceil((debt+back)/20))
            return dict(hp=max(0,hp_after_combat-loss), forced_loss=loss,
                        cause=name, debt=debt, return_time=back, records=records)
    return dict(hp=hp_after_combat, forced_loss=0, remaining=remaining, records=records)

if __name__ == '__main__':
    outputs = {}
    for name, params in CASES.items():
        r = encounter(**params)
        actual = tuple(r[k] for k in ('outcome','ctb','scene_time','hp','durability','coat','bleeding','contusion'))
        assert actual == EXPECTED[name], (name,actual,EXPECTED[name])
        outputs[name] = r
    routes = {
        'defended_full_loot': full_loot_route(ctb_cost=40, hp_after_combat=3),
        'basic_full_loot_no_injury': full_loot_route(ctb_cost=30, hp_after_combat=1),
        'basic_full_loot_contusion': full_loot_route(ctb_cost=30, hp_after_combat=1, contusion=True),
    }
    assert routes['defended_full_loot']['hp'] == 2
    assert routes['defended_full_loot']['cause'] == '提取组件'
    assert routes['defended_full_loot']['debt'] == 0
    assert routes['defended_full_loot']['return_time'] == 20
    assert routes['basic_full_loot_no_injury']['hp'] == 0
    assert routes['basic_full_loot_contusion']['hp'] == 0
    # 新一日：只取件=3+1；拿齐=2+2，同为4但后者库存及工时不同。
    assert 3+1 == 2+2 == 4
    target = Path(__file__).parent/'paper_results.json'
    target.write_text(json.dumps(dict(method='Independent paper calculator, not production resolver',
                                     combat=outputs,routes=routes), ensure_ascii=False,indent=2),encoding='utf-8')
    for name,r in outputs.items():
        print(name, {k:r[k] for k in ('outcome','ctb','scene_time','hp','durability','coat','bleeding','contusion')})
    for name,r in routes.items(): print(name, {k:v for k,v in r.items() if k!='records'})
    print('10 scripted combat branches + 3 route branches checked. Not production tests.')
